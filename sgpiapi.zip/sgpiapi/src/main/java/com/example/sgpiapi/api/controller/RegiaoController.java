package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.RegiaoDTO;
import com.example.sgpiapi.service.RegiaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/regioes")
public class RegiaoController {

    @Autowired
    private RegiaoService service;

    @PostMapping
    public ResponseEntity<RegiaoDTO> salvar(@RequestBody RegiaoDTO dto){

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<RegiaoDTO>> listar(){

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<RegiaoDTO> buscarPorId(@PathVariable Long id){

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<RegiaoDTO> atualizar(@PathVariable Long id,
                                               @RequestBody RegiaoDTO dto){

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id){

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}
