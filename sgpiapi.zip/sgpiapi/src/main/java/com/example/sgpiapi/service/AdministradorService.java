package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.AdministradorDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Administrador;
import com.example.sgpiapi.model.entity.SituacaoUsuario;
import com.example.sgpiapi.model.entity.Usuario;
import com.example.sgpiapi.model.repository.SituacaoUsuarioRepository;
import com.example.sgpiapi.model.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdministradorService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private SituacaoUsuarioRepository situacaoUsuarioRepository;

    public AdministradorDTO salvar(AdministradorDTO dto) {

        SituacaoUsuario situacao = situacaoUsuarioRepository.findById(dto.getSituacaoUsuarioId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        Administrador administrador = new Administrador();
        administrador.setNomeCompleto(dto.getNomeCompleto());
        administrador.setCpf(dto.getCpf());
        administrador.setEmail(dto.getEmail());
        administrador.setSenha(dto.getSenha());
        administrador.setDataRegistro(dto.getDataRegistro());
        administrador.setSituacaoUsuario(situacao);

        administrador = usuarioRepository.save(administrador);

        return converterParaDTO(administrador);
    }

    public List<AdministradorDTO> listar() {

        return usuarioRepository.findAll()
                .stream()
                .filter(usuario -> usuario instanceof Administrador)
                .map(usuario -> converterParaDTO((Administrador) usuario))
                .collect(Collectors.toList());
    }

    public AdministradorDTO buscarPorId(Long id) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Administrador não encontrado."));


		if (!(usuario instanceof Administrador)) {
    			throw new ObjetoNaoEncontradoException("Administrador não encontrado.");
		}

		Administrador administrador = (Administrador) usuario;

		return converterParaDTO(administrador);
    }

    public AdministradorDTO atualizar(Long id, AdministradorDTO dto) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Administrador não encontrado."));

        if (!(usuario instanceof Administrador administrador)) {
            throw new ObjetoNaoEncontradoException("Administrador não encontrado.");
        }

        SituacaoUsuario situacao = situacaoUsuarioRepository.findById(dto.getSituacaoUsuarioId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        administrador.setNomeCompleto(dto.getNomeCompleto());
        administrador.setCpf(dto.getCpf());
        administrador.setEmail(dto.getEmail());
        administrador.setSenha(dto.getSenha());
        administrador.setDataRegistro(dto.getDataRegistro());
        administrador.setSituacaoUsuario(situacao);

        usuarioRepository.save(administrador);

        return converterParaDTO(administrador);
    }

    public void excluir(Long id) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Administrador não encontrado."));

        if (!(usuario instanceof Administrador)) {
            throw new ObjetoNaoEncontradoException("Administrador não encontrado.");
        }

        usuarioRepository.delete(usuario);
    }

    private AdministradorDTO converterParaDTO(Administrador administrador) {

        AdministradorDTO dto = new AdministradorDTO();

        dto.setId(administrador.getId());
        dto.setNomeCompleto(administrador.getNomeCompleto());
        dto.setCpf(administrador.getCpf());
        dto.setEmail(administrador.getEmail());
        dto.setSenha(administrador.getSenha());
        dto.setDataRegistro(administrador.getDataRegistro());
        dto.setSituacaoUsuarioId(administrador.getSituacaoUsuario().getId());

        return dto;
    }
}