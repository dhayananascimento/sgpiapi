package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.MovimentacaoEstoqueDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Material;
import com.example.sgpiapi.model.entity.MovimentacaoEstoque;
import com.example.sgpiapi.model.entity.TipoMovimentacao;
import com.example.sgpiapi.model.repository.MaterialRepository;
import com.example.sgpiapi.model.repository.MovimentacaoEstoqueRepository;
import com.example.sgpiapi.model.repository.TipoMovimentacaoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MovimentacaoEstoqueService {

    @Autowired
    private MovimentacaoEstoqueRepository repository;

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private TipoMovimentacaoRepository tipoMovimentacaoRepository;

    @Autowired
    private ModelMapper mapper;

    public MovimentacaoEstoqueDTO salvar(MovimentacaoEstoqueDTO dto){

        Material material = materialRepository.findById(dto.getMaterialId())
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Material não encontrado."));

        TipoMovimentacao tipoMovimentacao = tipoMovimentacaoRepository.findById(dto.getTipoMovimentacaoId())
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Tipo de movimentação não encontrado."));

        aplicarMovimentacao(material, tipoMovimentacao, dto.getQuantidade());

        MovimentacaoEstoque movimentacao = new MovimentacaoEstoque();

        movimentacao.setMaterial(material);
        movimentacao.setTipoMovimentacao(tipoMovimentacao);
        movimentacao.setQuantidade(dto.getQuantidade());
        movimentacao.setObservacao(dto.getObservacao());

        if (dto.getData() == null) {
            movimentacao.setData(LocalDateTime.now());
        } else {
            movimentacao.setData(dto.getData());
        }

        movimentacao = repository.save(movimentacao);

        return converterParaDTO(movimentacao);
    }

    public List<MovimentacaoEstoqueDTO> listar(){

        return repository.findAll()
                .stream()
                .map(this::converterParaDTO)
                .collect(Collectors.toList());
    }

    public MovimentacaoEstoqueDTO buscarPorId(Long id){

        MovimentacaoEstoque movimentacao = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Movimentação não encontrada."));

        return converterParaDTO(movimentacao);
    }

    public MovimentacaoEstoqueDTO atualizar(Long id, MovimentacaoEstoqueDTO dto){

        MovimentacaoEstoque movimentacao = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Movimentação não encontrada."));

        desfazerMovimentacao(
                movimentacao.getMaterial(),
                movimentacao.getTipoMovimentacao(),
                movimentacao.getQuantidade());

        Material material = materialRepository.findById(dto.getMaterialId())
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Material não encontrado."));

        TipoMovimentacao tipoMovimentacao = tipoMovimentacaoRepository.findById(dto.getTipoMovimentacaoId())
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Tipo de movimentação não encontrado."));

        aplicarMovimentacao(material, tipoMovimentacao, dto.getQuantidade());

        movimentacao.setMaterial(material);
        movimentacao.setTipoMovimentacao(tipoMovimentacao);
        movimentacao.setQuantidade(dto.getQuantidade());
        movimentacao.setObservacao(dto.getObservacao());

        if (dto.getData() == null) {
            movimentacao.setData(LocalDateTime.now());
        } else {
            movimentacao.setData(dto.getData());
        }

        repository.save(movimentacao);

        return converterParaDTO(movimentacao);
    }

    public void excluir(Long id){

        MovimentacaoEstoque movimentacao = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Movimentação não encontrada."));

        desfazerMovimentacao(
                movimentacao.getMaterial(),
                movimentacao.getTipoMovimentacao(),
                movimentacao.getQuantidade());

        repository.delete(movimentacao);
    }

    private void aplicarMovimentacao(Material material,
                                     TipoMovimentacao tipoMovimentacao,
                                     Integer quantidade){

        Integer estoque = material.getQuantidadeEstoque();

        if (estoque == null) {
            estoque = 0;
        }

        if (tipoMovimentacao.getOperacao() == 'E') {

            material.setQuantidadeEstoque(estoque + quantidade);

        } else if (tipoMovimentacao.getOperacao() == 'S') {

            if (estoque < quantidade) {
                throw new IllegalArgumentException("Estoque insuficiente.");
            }

            material.setQuantidadeEstoque(estoque - quantidade);

        } else {

            throw new IllegalArgumentException("Operação de movimentação inválida.");

        }

        materialRepository.save(material);
    }

    private void desfazerMovimentacao(Material material,
                                      TipoMovimentacao tipoMovimentacao,
                                      Integer quantidade){

        Integer estoque = material.getQuantidadeEstoque();

        if (estoque == null) {
            estoque = 0;
        }

        if (tipoMovimentacao.getOperacao() == 'E') {

            if (estoque < quantidade) {
                throw new IllegalArgumentException("Operação inválida.");
            }

            material.setQuantidadeEstoque(estoque - quantidade);

        } else if (tipoMovimentacao.getOperacao() == 'S') {

            material.setQuantidadeEstoque(estoque + quantidade);

        } else {

            throw new IllegalArgumentException("Operação de movimentação inválida.");

        }

        materialRepository.save(material);
    }

    private MovimentacaoEstoqueDTO converterParaDTO(MovimentacaoEstoque entity){

        MovimentacaoEstoqueDTO dto = mapper.map(entity, MovimentacaoEstoqueDTO.class);

        dto.setMaterialId(entity.getMaterial().getId());
        dto.setTipoMovimentacaoId(entity.getTipoMovimentacao().getId());

        return dto;
    }

}
