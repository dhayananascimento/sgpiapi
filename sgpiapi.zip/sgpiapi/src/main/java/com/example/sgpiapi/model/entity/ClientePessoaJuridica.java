package com.example.sgpiapi.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "cliente_pj")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class ClientePessoaJuridica extends Cliente {

    @Column(nullable = false)
    private String razaoSocial;

    @Column(nullable = false, unique = true)
    private String cnpj;

    @Column(nullable = false)
    private String nomeResponsavel;

    @Column(nullable = false)
    private String cpfResponsavel;
}