package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.DiagnosticoFinalDTO;
import com.example.sgpiapi.service.DiagnosticoFinalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/diagnosticos-finais")
public class DiagnosticoFinalController {

    @Autowired
    private DiagnosticoFinalService service;

    @PostMapping
    public ResponseEntity<DiagnosticoFinalDTO> salvar(@RequestBody DiagnosticoFinalDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<DiagnosticoFinalDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DiagnosticoFinalDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<DiagnosticoFinalDTO> atualizar(@PathVariable Long id,
                                                         @RequestBody DiagnosticoFinalDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}