package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.AtendimentoDTO;
import com.example.sgpiapi.model.entity.*;
import com.example.sgpiapi.model.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AtendimentoService {

    private final AtendimentoRepository repository;
    private final TipoAtendimentoRepository tipoAtendimentoRepository;
    private final StatusAtendimentoRepository statusAtendimentoRepository;
    private final AtendenteRepository atendenteRepository;
    private final ContratoRepository contratoRepository;

    public AtendimentoService(
            AtendimentoRepository repository,
            TipoAtendimentoRepository tipoAtendimentoRepository,
            StatusAtendimentoRepository statusAtendimentoRepository,
            AtendenteRepository atendenteRepository,
            ContratoRepository contratoRepository) {

        this.repository = repository;
        this.tipoAtendimentoRepository = tipoAtendimentoRepository;
        this.statusAtendimentoRepository = statusAtendimentoRepository;
        this.atendenteRepository = atendenteRepository;
        this.contratoRepository = contratoRepository;
    }

    public List<AtendimentoDTO> listarTodos() {
        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public AtendimentoDTO buscarPorId(Long id) {

        Atendimento atendimento = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Atendimento não encontrado"));

        return toDTO(atendimento);
    }

    public AtendimentoDTO salvar(AtendimentoDTO dto) {

        Atendimento atendimento = new Atendimento();

        preencherDados(atendimento, dto);

        return toDTO(repository.save(atendimento));
    }

    public AtendimentoDTO atualizar(Long id, AtendimentoDTO dto) {

        Atendimento atendimento = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Atendimento não encontrado"));

        preencherDados(atendimento, dto);

        return toDTO(repository.save(atendimento));
    }

    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Atendimento não encontrado");
        }

        repository.deleteById(id);
    }


    private void preencherDados(Atendimento atendimento, AtendimentoDTO dto) {

        atendimento.setDescricao(dto.getDescricao());
        atendimento.setDataHora(dto.getDataHora());

        atendimento.setTipoAtendimento(
                tipoAtendimentoRepository.findById(dto.getTipoAtendimentoId())
                        .orElseThrow(() -> new RuntimeException("Tipo de atendimento não encontrado"))
        );

        atendimento.setStatus(
                statusAtendimentoRepository.findById(dto.getStatusAtendimentoId())
                        .orElseThrow(() -> new RuntimeException("Status de atendimento não encontrado"))
        );

        atendimento.setAtendente(
                atendenteRepository.findById(dto.getAtendenteId())
                        .orElseThrow(() -> new RuntimeException("Atendente não encontrado"))
        );

        atendimento.setContrato(
                contratoRepository.findById(dto.getContratoId())
                        .orElseThrow(() -> new RuntimeException("Contrato não encontrado"))
        );
    }


    private AtendimentoDTO toDTO(Atendimento atendimento) {

        AtendimentoDTO dto = new AtendimentoDTO();

        dto.setId(atendimento.getId());
        dto.setDescricao(atendimento.getDescricao());
        dto.setDataHora(atendimento.getDataHora());

        dto.setTipoAtendimentoId(
                atendimento.getTipoAtendimento().getId()
        );

        dto.setStatusAtendimentoId(
                atendimento.getStatus().getId()
        );

        dto.setAtendenteId(
                atendimento.getAtendente().getId()
        );

        dto.setContratoId(
                atendimento.getContrato().getId()
        );

        return dto;
    }
}