package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MaterialDTO {

    private Long id;
    private String nome;
    private Long unidadeMedidaId;
    private BigDecimal valorUnitario;
    private Integer quantidadeEstoque;

}
