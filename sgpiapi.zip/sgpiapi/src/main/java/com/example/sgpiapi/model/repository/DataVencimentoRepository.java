package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.DataVencimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DataVencimentoRepository extends JpaRepository<DataVencimento, Long> {

}
