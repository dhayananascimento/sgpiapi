package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.PrioridadeDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Prioridade;
import com.example.sgpiapi.model.repository.PrioridadeRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PrioridadeService {

    @Autowired
    private PrioridadeRepository repository;

    @Autowired
    private ModelMapper mapper;

    public PrioridadeDTO salvar(PrioridadeDTO dto) {

        Prioridade entity = mapper.map(dto, Prioridade.class);

        entity = repository.save(entity);

        return mapper.map(entity, PrioridadeDTO.class);
    }

    public List<PrioridadeDTO> listar() {

        return repository.findAll()
                .stream()
                .map(entity -> mapper.map(entity, PrioridadeDTO.class))
                .collect(Collectors.toList());
    }

    public PrioridadeDTO buscarPorId(Long id) {

        Prioridade entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Prioridade não encontrada."));

        return mapper.map(entity, PrioridadeDTO.class);
    }

    public PrioridadeDTO atualizar(Long id, PrioridadeDTO dto) {

        Prioridade entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Prioridade não encontrada."));

        entity.setNome(dto.getNome());
        entity.setPrazoMaximoHoras(dto.getPrazoMaximoHoras());

        repository.save(entity);

        return mapper.map(entity, PrioridadeDTO.class);
    }

    public void excluir(Long id) {

        Prioridade entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Prioridade não encontrada."));

        repository.delete(entity);
    }

}
