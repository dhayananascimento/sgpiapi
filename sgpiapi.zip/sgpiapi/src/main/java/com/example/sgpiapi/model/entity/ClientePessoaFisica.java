package com.example.sgpiapi.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "cliente_pf")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class ClientePessoaFisica extends Cliente {

    @Column(nullable = false)
    private String nomeCompleto;

    @Column(nullable = false, unique = true)
    private String cpf;

    @Column(nullable = false)
    private Boolean brasileiro;
}