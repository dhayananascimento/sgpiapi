package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.TipoRegistroOrdemServicoDTO;
import com.example.sgpiapi.service.TipoRegistroOrdemServicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tipos-registros-ordens-servico")
public class TipoRegistroOrdemServicoController {

    @Autowired
    private TipoRegistroOrdemServicoService service;

    @PostMapping
    public ResponseEntity<TipoRegistroOrdemServicoDTO> salvar(@RequestBody TipoRegistroOrdemServicoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<TipoRegistroOrdemServicoDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoRegistroOrdemServicoDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TipoRegistroOrdemServicoDTO> atualizar(@PathVariable Long id,
                                                                 @RequestBody TipoRegistroOrdemServicoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}