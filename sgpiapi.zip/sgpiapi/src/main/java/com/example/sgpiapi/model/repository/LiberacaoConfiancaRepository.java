package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.LiberacaoConfianca;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LiberacaoConfiancaRepository extends JpaRepository<LiberacaoConfianca, Long> {

}
