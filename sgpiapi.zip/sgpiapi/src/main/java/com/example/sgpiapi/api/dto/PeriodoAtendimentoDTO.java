package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PeriodoAtendimentoDTO {

    private Long id;
    private String nome;
    private LocalTime horaInicial;
    private LocalTime horaFinal;

}
