package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.SituacaoUsuarioDTO;
import com.example.sgpiapi.service.SituacaoUsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/situacoes-usuarios")
public class SituacaoUsuarioController {

    @Autowired
    private SituacaoUsuarioService service;

    @PostMapping
    public ResponseEntity<SituacaoUsuarioDTO> salvar(@RequestBody SituacaoUsuarioDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<SituacaoUsuarioDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SituacaoUsuarioDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<SituacaoUsuarioDTO> atualizar(@PathVariable Long id,
                                                        @RequestBody SituacaoUsuarioDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}