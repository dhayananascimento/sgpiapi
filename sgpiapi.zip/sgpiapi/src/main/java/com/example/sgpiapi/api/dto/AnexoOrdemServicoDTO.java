package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnexoOrdemServicoDTO {

    private Long id;
    private Long ordemServicoId;
    private String nomeArquivo;
    private String tipoArquivo;
    private Long tamanhoArquivo;
    private String caminhoArquivo;

}
