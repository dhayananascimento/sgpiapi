package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.ContratoDTO;
import com.example.sgpiapi.service.ContratoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/contrato")
public class ContratoController {

    private final ContratoService service;


    public ContratoController(ContratoService service) {
        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<ContratoDTO>> listarTodos() {

        return ResponseEntity.ok(service.listarTodos());
    }


    @GetMapping("/{id}")
    public ResponseEntity<ContratoDTO> buscarPorId(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PostMapping
    public ResponseEntity<ContratoDTO> salvar(
            @RequestBody ContratoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @PutMapping("/{id}")
    public ResponseEntity<ContratoDTO> atualizar(
            @PathVariable Long id,
            @RequestBody ContratoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}