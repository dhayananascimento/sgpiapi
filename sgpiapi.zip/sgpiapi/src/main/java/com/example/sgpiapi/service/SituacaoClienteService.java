package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.SituacaoClienteDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.SituacaoCliente;
import com.example.sgpiapi.model.repository.SituacaoClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SituacaoClienteService {

    @Autowired
    private SituacaoClienteRepository repository;


    public SituacaoClienteDTO salvar(SituacaoClienteDTO dto) {

        SituacaoCliente situacao = new SituacaoCliente();

        situacao.setNome(dto.getNome());
        situacao.setDescricao(dto.getDescricao());

        situacao = repository.save(situacao);

        return converterParaDTO(situacao);
    }


    public List<SituacaoClienteDTO> listar() {

        return repository.findAll()
                .stream()
                .map(this::converterParaDTO)
                .collect(Collectors.toList());
    }


    public SituacaoClienteDTO buscarPorId(Long id) {

        SituacaoCliente situacao = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do cliente não encontrada."));

        return converterParaDTO(situacao);
    }


    public SituacaoClienteDTO atualizar(Long id, SituacaoClienteDTO dto) {

        SituacaoCliente situacao = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do cliente não encontrada."));

        situacao.setNome(dto.getNome());
        situacao.setDescricao(dto.getDescricao());

        repository.save(situacao);

        return converterParaDTO(situacao);
    }


    public void excluir(Long id) {

        SituacaoCliente situacao = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do cliente não encontrada."));

        repository.delete(situacao);
    }


    private SituacaoClienteDTO converterParaDTO(SituacaoCliente situacao) {

        SituacaoClienteDTO dto = new SituacaoClienteDTO();

        dto.setId(situacao.getId());
        dto.setNome(situacao.getNome());
        dto.setDescricao(situacao.getDescricao());

        return dto;
    }

}