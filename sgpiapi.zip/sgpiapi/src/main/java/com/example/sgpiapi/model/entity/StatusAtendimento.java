package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "status_atendimento")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StatusAtendimento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    private String descricao;
}