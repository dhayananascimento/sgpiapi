package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "agendamento")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Agendamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "ordem_servico_id", nullable = false)
    private OrdemServico ordemServico;

    @Column(nullable = false)
    private LocalDate data;

    @ManyToOne
    @JoinColumn(name = "periodo_id", nullable = false)
    private PeriodoAtendimento periodo;

    @Column(nullable = false)
    private LocalTime horaInicial;

    @Column(nullable = false)
    private LocalTime horaFinal;

    @Column(length = 500)
    private String motivoReagendamento;

    @ManyToOne
    @JoinColumn(name = "tecnico_id", nullable = false)
    private Tecnico tecnicoResponsavel;
}