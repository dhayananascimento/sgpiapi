package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.MaterialDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Material;
import com.example.sgpiapi.model.entity.UnidadeMedida;
import com.example.sgpiapi.model.repository.MaterialRepository;
import com.example.sgpiapi.model.repository.UnidadeMedidaRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MaterialService {

    @Autowired
    private MaterialRepository repository;

    @Autowired
    private UnidadeMedidaRepository unidadeMedidaRepository;

    @Autowired
    private ModelMapper mapper;

    public MaterialDTO salvar(MaterialDTO dto) {

        UnidadeMedida unidadeMedida = unidadeMedidaRepository.findById(dto.getUnidadeMedidaId())
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Unidade de medida não encontrada."));

        Material material = new Material();

        material.setNome(dto.getNome());
        material.setUnidadeMedida(unidadeMedida);
        material.setValorUnitario(dto.getValorUnitario());
        material.setQuantidadeEstoque(dto.getQuantidadeEstoque());

        material = repository.save(material);

        MaterialDTO retorno = mapper.map(material, MaterialDTO.class);
        retorno.setUnidadeMedidaId(material.getUnidadeMedida().getId());

        return retorno;
    }

    public List<MaterialDTO> listar() {

        return repository.findAll()
                .stream()
                .map(material -> {
                    MaterialDTO dto = mapper.map(material, MaterialDTO.class);
                    dto.setUnidadeMedidaId(material.getUnidadeMedida().getId());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    public MaterialDTO buscarPorId(Long id) {

        Material material = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Material não encontrado."));

        MaterialDTO dto = mapper.map(material, MaterialDTO.class);
        dto.setUnidadeMedidaId(material.getUnidadeMedida().getId());

        return dto;
    }

    public MaterialDTO atualizar(Long id, MaterialDTO dto) {

        Material material = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Material não encontrado."));

        UnidadeMedida unidadeMedida = unidadeMedidaRepository.findById(dto.getUnidadeMedidaId())
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Unidade de medida não encontrada."));

        material.setNome(dto.getNome());
        material.setUnidadeMedida(unidadeMedida);
        material.setValorUnitario(dto.getValorUnitario());
        material.setQuantidadeEstoque(dto.getQuantidadeEstoque());

        repository.save(material);

        MaterialDTO retorno = mapper.map(material, MaterialDTO.class);
        retorno.setUnidadeMedidaId(material.getUnidadeMedida().getId());

        return retorno;
    }

    public void excluir(Long id) {

        Material material = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Material não encontrado."));

        repository.delete(material);
    }

}
