package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.Atendente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AtendenteRepository extends JpaRepository<Atendente, Long> {
}
