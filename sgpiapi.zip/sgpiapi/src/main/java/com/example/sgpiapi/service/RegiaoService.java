package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.RegiaoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Regiao;
import com.example.sgpiapi.model.repository.RegiaoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RegiaoService {

    @Autowired
    private RegiaoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public RegiaoDTO salvar(RegiaoDTO dto) {
        Regiao regiao = mapper.map(dto, Regiao.class);
        regiao = repository.save(regiao);
        return mapper.map(regiao, RegiaoDTO.class);
    }

    public List<RegiaoDTO> listar() {
        return repository.findAll()
                .stream()
                .map(regiao -> mapper.map(regiao, RegiaoDTO.class))
                .collect(Collectors.toList());
    }

    public RegiaoDTO buscarPorId(Long id) {

        Regiao regiao = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Região não encontrada."));

        return mapper.map(regiao, RegiaoDTO.class);
    }

    public RegiaoDTO atualizar(Long id, RegiaoDTO dto) {

        Regiao regiao = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Região não encontrada."));

        regiao.setNome(dto.getNome());
        regiao.setSigla(dto.getSigla());

        repository.save(regiao);

        return mapper.map(regiao, RegiaoDTO.class);
    }

    public void excluir(Long id) {

        Regiao regiao = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Região não encontrada."));

        repository.delete(regiao);
    }

}
