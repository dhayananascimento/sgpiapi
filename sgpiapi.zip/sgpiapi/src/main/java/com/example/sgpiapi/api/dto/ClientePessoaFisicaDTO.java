package com.example.sgpiapi.api.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class ClientePessoaFisicaDTO extends ClienteDTO {

    private String nomeCompleto;
    private String cpf;
    private Boolean brasileiro;

}
