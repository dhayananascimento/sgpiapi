package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LocalizacaoTecnicoDTO {

    private Long id;
    private Long tecnicoId;
    private Double latitude;
    private Double longitude;
    private LocalDateTime dataHora;

}
