package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.ClientePessoaFisicaDTO;
import com.example.sgpiapi.service.ClientePessoaFisicaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clientes/pessoa-fisica")
public class ClientePessoaFisicaController {

    @Autowired
    private ClientePessoaFisicaService service;


    @PostMapping
    public ResponseEntity<ClientePessoaFisicaDTO> salvar(@RequestBody ClientePessoaFisicaDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @GetMapping
    public ResponseEntity<List<ClientePessoaFisicaDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }


    @GetMapping("/{id}")
    public ResponseEntity<ClientePessoaFisicaDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PutMapping("/{id}")
    public ResponseEntity<ClientePessoaFisicaDTO> atualizar(@PathVariable Long id,
                                                            @RequestBody ClientePessoaFisicaDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}