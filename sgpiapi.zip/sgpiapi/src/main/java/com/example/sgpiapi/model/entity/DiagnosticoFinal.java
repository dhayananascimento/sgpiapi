package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "diagnostico_final")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DiagnosticoFinal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;
}