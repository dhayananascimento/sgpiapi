package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgendamentoDTO {

    private Long id;
    private Long ordemServicoId;
    private LocalDate data;
    private Long periodoAtendimentoId;
    private LocalTime horaInicial;
    private LocalTime horaFinal;
    private Long tecnicoId;
    private String motivoReagendamento;

}
