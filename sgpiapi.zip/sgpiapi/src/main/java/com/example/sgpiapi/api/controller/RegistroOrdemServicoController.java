package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.RegistroOrdemServicoDTO;
import com.example.sgpiapi.service.RegistroOrdemServicoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/registro-ordem-servico")
public class RegistroOrdemServicoController {

    private final RegistroOrdemServicoService service;


    public RegistroOrdemServicoController(
            RegistroOrdemServicoService service) {

        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<RegistroOrdemServicoDTO>> listarTodos() {

        return ResponseEntity.ok(service.listarTodos());
    }


    @GetMapping("/{id}")
    public ResponseEntity<RegistroOrdemServicoDTO> buscarPorId(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PostMapping
    public ResponseEntity<RegistroOrdemServicoDTO> salvar(
            @RequestBody RegistroOrdemServicoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @PutMapping("/{id}")
    public ResponseEntity<RegistroOrdemServicoDTO> atualizar(
            @PathVariable Long id,
            @RequestBody RegistroOrdemServicoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}