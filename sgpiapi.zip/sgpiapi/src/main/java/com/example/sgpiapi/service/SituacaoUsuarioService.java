package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.SituacaoUsuarioDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.SituacaoUsuario;
import com.example.sgpiapi.model.repository.SituacaoUsuarioRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SituacaoUsuarioService {

    @Autowired
    private SituacaoUsuarioRepository repository;

    @Autowired
    private ModelMapper mapper;

    public SituacaoUsuarioDTO salvar(SituacaoUsuarioDTO dto) {

        SituacaoUsuario situacaoUsuario = mapper.map(dto, SituacaoUsuario.class);

        situacaoUsuario = repository.save(situacaoUsuario);

        return mapper.map(situacaoUsuario, SituacaoUsuarioDTO.class);
    }

    public List<SituacaoUsuarioDTO> listar() {

        return repository.findAll()
                .stream()
                .map(situacaoUsuario -> mapper.map(situacaoUsuario, SituacaoUsuarioDTO.class))
                .collect(Collectors.toList());
    }

    public SituacaoUsuarioDTO buscarPorId(Long id) {

        SituacaoUsuario situacaoUsuario = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        return mapper.map(situacaoUsuario, SituacaoUsuarioDTO.class);
    }

    public SituacaoUsuarioDTO atualizar(Long id, SituacaoUsuarioDTO dto) {

        SituacaoUsuario situacaoUsuario = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        situacaoUsuario.setNome(dto.getNome());
        situacaoUsuario.setDescricao(dto.getDescricao());

        repository.save(situacaoUsuario);

        return mapper.map(situacaoUsuario, SituacaoUsuarioDTO.class);
    }

    public void excluir(Long id) {

        SituacaoUsuario situacaoUsuario = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        repository.delete(situacaoUsuario);
    }
}