package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.ClientePessoaJuridicaDTO;
import com.example.sgpiapi.service.ClientePessoaJuridicaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clientes/pessoa-juridica")
public class ClientePessoaJuridicaController {

    @Autowired
    private ClientePessoaJuridicaService service;


    @PostMapping
    public ResponseEntity<ClientePessoaJuridicaDTO> salvar(@RequestBody ClientePessoaJuridicaDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @GetMapping
    public ResponseEntity<List<ClientePessoaJuridicaDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }


    @GetMapping("/{id}")
    public ResponseEntity<ClientePessoaJuridicaDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


	@PutMapping("/{id}")
    public ResponseEntity<ClientePessoaJuridicaDTO> atualizar(@PathVariable Long id,
                                                              @RequestBody ClientePessoaJuridicaDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}