package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.TipoAtendimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TipoAtendimentoRepository extends JpaRepository<TipoAtendimento, Long> {

}
