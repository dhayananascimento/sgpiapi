package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.PeriodoAtendimentoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.PeriodoAtendimento;
import com.example.sgpiapi.model.repository.PeriodoAtendimentoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PeriodoAtendimentoService {

    @Autowired
    private PeriodoAtendimentoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public PeriodoAtendimentoDTO salvar(PeriodoAtendimentoDTO dto) {

        PeriodoAtendimento entity = mapper.map(dto, PeriodoAtendimento.class);

        entity = repository.save(entity);

        return mapper.map(entity, PeriodoAtendimentoDTO.class);
    }

    public List<PeriodoAtendimentoDTO> listar() {

        return repository.findAll()
                .stream()
                .map(entity -> mapper.map(entity, PeriodoAtendimentoDTO.class))
                .collect(Collectors.toList());
    }

    public PeriodoAtendimentoDTO buscarPorId(Long id) {

        PeriodoAtendimento entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Período de atendimento não encontrado."));

        return mapper.map(entity, PeriodoAtendimentoDTO.class);
    }

    public PeriodoAtendimentoDTO atualizar(Long id, PeriodoAtendimentoDTO dto) {

        PeriodoAtendimento entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Período de atendimento não encontrado."));

        entity.setNome(dto.getNome());
        entity.setHoraInicial(dto.getHoraInicial());
        entity.setHoraFinal(dto.getHoraFinal());

        repository.save(entity);

        return mapper.map(entity, PeriodoAtendimentoDTO.class);
    }

    public void excluir(Long id) {

        PeriodoAtendimento entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Período de atendimento não encontrado."));

        repository.delete(entity);
    }

}
