package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tecnico")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Tecnico extends Usuario {

    @ManyToOne
    @JoinColumn(name = "regiao_principal_id", nullable = false)
    private Regiao regiaoPrincipal;
}