package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "data_vencimento")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataVencimento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Integer diaNumerico;

    @Column(nullable = false, length = 20)
    private String diaExtenso;
}