package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.Tecnico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TecnicoRepository extends JpaRepository<Tecnico, Long> {
}
