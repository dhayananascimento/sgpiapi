package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ContratoDTO {

    private Long id;
    private Long clienteId;
    private Long planoInternetId;
    private Long enderecoId;
    private LocalDate dataAtivacao;
    private Long dataVencimentoId;
    private Long situacaoContratoId;
    private String observacao;

}
