package com.example.sgpiapi.api.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class TecnicoDTO extends UsuarioDTO {

    private Long regiaoPrincipalId;

}
