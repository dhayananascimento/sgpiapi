package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "contrato")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Contrato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "plano_internet_id", nullable = false)
    private PlanoInternet planoInternet;

    @ManyToOne
    @JoinColumn(name = "endereco_id", nullable = false)
    private Endereco endereco;

    @Column(nullable = false)
    private LocalDate dataAtivacao;

    @ManyToOne
    @JoinColumn(name = "data_vencimento_id", nullable = false)
    private DataVencimento dataVencimento;

    @ManyToOne
    @JoinColumn(name = "situacao_contrato_id", nullable = false)
    private SituacaoContrato situacaoContrato;

    @Column(length = 500)
    private String observacao;
}
