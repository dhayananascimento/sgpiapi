package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.SituacaoContratoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.SituacaoContrato;
import com.example.sgpiapi.model.repository.SituacaoContratoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SituacaoContratoService {

    @Autowired
    private SituacaoContratoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public SituacaoContratoDTO salvar(SituacaoContratoDTO dto) {

        SituacaoContrato situacaoContrato = mapper.map(dto, SituacaoContrato.class);

        situacaoContrato = repository.save(situacaoContrato);

        return mapper.map(situacaoContrato, SituacaoContratoDTO.class);
    }

    public List<SituacaoContratoDTO> listar() {

        return repository.findAll()
                .stream()
                .map(situacaoContrato -> mapper.map(situacaoContrato, SituacaoContratoDTO.class))
                .collect(Collectors.toList());
    }

    public SituacaoContratoDTO buscarPorId(Long id) {

        SituacaoContrato situacaoContrato = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do contrato não encontrada."));

        return mapper.map(situacaoContrato, SituacaoContratoDTO.class);
    }

    public SituacaoContratoDTO atualizar(Long id, SituacaoContratoDTO dto) {

        SituacaoContrato situacaoContrato = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do contrato não encontrada."));

        situacaoContrato.setNome(dto.getNome());
        situacaoContrato.setDescricao(dto.getDescricao());

        repository.save(situacaoContrato);

        return mapper.map(situacaoContrato, SituacaoContratoDTO.class);
    }

    public void excluir(Long id) {

        SituacaoContrato situacaoContrato = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do contrato não encontrada."));

        repository.delete(situacaoContrato);
    }
}