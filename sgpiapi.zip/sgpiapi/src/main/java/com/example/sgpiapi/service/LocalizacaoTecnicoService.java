package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.LocalizacaoTecnicoDTO;
import com.example.sgpiapi.model.entity.LocalizacaoTecnico;
import com.example.sgpiapi.model.entity.Tecnico;
import com.example.sgpiapi.model.repository.LocalizacaoTecnicoRepository;
import com.example.sgpiapi.model.repository.TecnicoRepository;
import org.springframework.stereotype.Service;
import com.example.sgpiapi.model.repository.OrdemServicoRepository;
import com.example.sgpiapi.model.entity.OrdemServico;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LocalizacaoTecnicoService {

    private final LocalizacaoTecnicoRepository repository;
    private final TecnicoRepository tecnicoRepository;
    private final OrdemServicoRepository ordemServicoRepository;


public LocalizacaoTecnicoService(
        LocalizacaoTecnicoRepository repository,
        TecnicoRepository tecnicoRepository,
        OrdemServicoRepository ordemServicoRepository) {

    this.repository = repository;
    this.tecnicoRepository = tecnicoRepository;
    this.ordemServicoRepository = ordemServicoRepository;
}


    public List<LocalizacaoTecnicoDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public LocalizacaoTecnicoDTO buscarPorId(Long id) {

        LocalizacaoTecnico localizacao = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Localização do técnico não encontrada"));

        return toDTO(localizacao);
    }


    public LocalizacaoTecnicoDTO salvar(LocalizacaoTecnicoDTO dto) {

        LocalizacaoTecnico localizacao = new LocalizacaoTecnico();

        preencherDados(localizacao, dto);

        return toDTO(repository.save(localizacao));
    }


    public LocalizacaoTecnicoDTO atualizar(
            Long id,
            LocalizacaoTecnicoDTO dto) {

        LocalizacaoTecnico localizacao = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Localização do técnico não encontrada"));

        preencherDados(localizacao, dto);

        return toDTO(repository.save(localizacao));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Localização do técnico não encontrada");
        }

        repository.deleteById(id);
    }


    private void preencherDados(
            LocalizacaoTecnico localizacao,
            LocalizacaoTecnicoDTO dto) {


        Tecnico tecnico =
                tecnicoRepository.findById(dto.getTecnicoId())
                        .orElseThrow(() ->
                                new RuntimeException("Técnico não encontrado"));

	OrdemServico ordemServico =
        	ordemServicoRepository.findById(dto.getOrdemServicoId())
                	.orElseThrow(() ->
                        	new RuntimeException("Ordem de serviço não encontrada"));

	localizacao.setOrdemServico(ordemServico);
        localizacao.setTecnico(tecnico);
        localizacao.setLatitude(dto.getLatitude());
        localizacao.setLongitude(dto.getLongitude());
        localizacao.setDataHora(dto.getDataHora());
    }


    private LocalizacaoTecnicoDTO toDTO(
            LocalizacaoTecnico localizacao) {


        LocalizacaoTecnicoDTO dto = new LocalizacaoTecnicoDTO();

        dto.setId(localizacao.getId());

        dto.setTecnicoId(
                localizacao.getTecnico().getId()
        );

	dto.setOrdemServicoId(
        	localizacao.getOrdemServico().getId()
	);

        dto.setLatitude(
                localizacao.getLatitude()
        );

        dto.setLongitude(
                localizacao.getLongitude()
        );

        dto.setDataHora(
                localizacao.getDataHora()
        );

        return dto;
    }
}