package com.example.sgpiapi.model.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "atendente")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Atendente extends Usuario {
}