package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.AgendamentoDTO;
import com.example.sgpiapi.service.AgendamentoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/agendamento")
public class AgendamentoController {

    private final AgendamentoService service;


    public AgendamentoController(AgendamentoService service) {
        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<AgendamentoDTO>> listarTodos() {

        return ResponseEntity.ok(service.listarTodos());
    }


    @GetMapping("/{id}")
    public ResponseEntity<AgendamentoDTO> buscarPorId(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PostMapping
    public ResponseEntity<AgendamentoDTO> salvar(
            @RequestBody AgendamentoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @PutMapping("/{id}")
    public ResponseEntity<AgendamentoDTO> atualizar(
            @PathVariable Long id,
            @RequestBody AgendamentoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}
