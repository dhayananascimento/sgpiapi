package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.TipoAtendimentoDTO;
import com.example.sgpiapi.model.entity.TipoAtendimento;
import com.example.sgpiapi.model.entity.TipoServico;
import com.example.sgpiapi.model.repository.TipoAtendimentoRepository;
import com.example.sgpiapi.model.repository.TipoServicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TipoAtendimentoService {

    private final TipoAtendimentoRepository repository;
    private final TipoServicoRepository tipoServicoRepository;

    public TipoAtendimentoService(
            TipoAtendimentoRepository repository,
            TipoServicoRepository tipoServicoRepository) {

        this.repository = repository;
        this.tipoServicoRepository = tipoServicoRepository;
    }

    public List<TipoAtendimentoDTO> listarTodos() {
        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public TipoAtendimentoDTO buscarPorId(Long id) {
        TipoAtendimento entidade = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Tipo de atendimento não encontrado"));

        return toDTO(entidade);
    }

    public TipoAtendimentoDTO salvar(TipoAtendimentoDTO dto) {

        TipoAtendimento entidade = new TipoAtendimento();

        entidade.setNome(dto.getNome());
        entidade.setDescricao(dto.getDescricao());
        entidade.setGeraOsAutomatica(dto.getGeraOsAutomatica());

        if (dto.getTipoServicoId() != null) {
            TipoServico tipoServico = tipoServicoRepository.findById(dto.getTipoServicoId())
                    .orElseThrow(() -> new RuntimeException("Tipo de serviço não encontrado"));

            entidade.setTipoServico(tipoServico);
        }

        return toDTO(repository.save(entidade));
    }

    public TipoAtendimentoDTO atualizar(Long id, TipoAtendimentoDTO dto) {

        TipoAtendimento entidade = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Tipo de atendimento não encontrado"));

        entidade.setNome(dto.getNome());
        entidade.setDescricao(dto.getDescricao());
        entidade.setGeraOsAutomatica(dto.getGeraOsAutomatica());

        if (dto.getTipoServicoId() != null) {

            TipoServico tipoServico = tipoServicoRepository.findById(dto.getTipoServicoId())
                    .orElseThrow(() -> new RuntimeException("Tipo de serviço não encontrado"));

            entidade.setTipoServico(tipoServico);
        }

        return toDTO(repository.save(entidade));
    }

    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Tipo de atendimento não encontrado");
        }

        repository.deleteById(id);
    }

    private TipoAtendimentoDTO toDTO(TipoAtendimento entidade) {

        TipoAtendimentoDTO dto = new TipoAtendimentoDTO();

        dto.setId(entidade.getId());
        dto.setNome(entidade.getNome());
        dto.setDescricao(entidade.getDescricao());
        dto.setGeraOsAutomatica(entidade.getGeraOsAutomatica());

        if (entidade.getTipoServico() != null) {
            dto.setTipoServicoId(entidade.getTipoServico().getId());
        }

        return dto;
    }
}