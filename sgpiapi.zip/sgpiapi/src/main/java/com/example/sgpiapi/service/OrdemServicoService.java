package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.OrdemServicoDTO;
import com.example.sgpiapi.model.entity.*;
import com.example.sgpiapi.model.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrdemServicoService {

    private final OrdemServicoRepository repository;
    private final ClienteRepository clienteRepository;
    private final ContratoRepository contratoRepository;
    private final TipoServicoRepository tipoServicoRepository;
    private final DiagnosticoInicialRepository diagnosticoInicialRepository;
    private final PrioridadeRepository prioridadeRepository;
    private final StatusOrdemServicoRepository statusRepository;


    public OrdemServicoService(
            OrdemServicoRepository repository,
            ClienteRepository clienteRepository,
            ContratoRepository contratoRepository,
            TipoServicoRepository tipoServicoRepository,
            DiagnosticoInicialRepository diagnosticoInicialRepository,
            PrioridadeRepository prioridadeRepository,
            StatusOrdemServicoRepository statusRepository) {

        this.repository = repository;
        this.clienteRepository = clienteRepository;
        this.contratoRepository = contratoRepository;
        this.tipoServicoRepository = tipoServicoRepository;
        this.diagnosticoInicialRepository = diagnosticoInicialRepository;
        this.prioridadeRepository = prioridadeRepository;
        this.statusRepository = statusRepository;
    }


    public List<OrdemServicoDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public OrdemServicoDTO buscarPorId(Long id) {

        OrdemServico ordemServico = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ordem de serviço não encontrada"));

        return toDTO(ordemServico);
    }


    public OrdemServicoDTO salvar(OrdemServicoDTO dto) {

        OrdemServico ordemServico = new OrdemServico();

        preencherDados(ordemServico, dto);

        return toDTO(repository.save(ordemServico));
    }


    public OrdemServicoDTO atualizar(Long id, OrdemServicoDTO dto) {

        OrdemServico ordemServico = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ordem de serviço não encontrada"));

        preencherDados(ordemServico, dto);

        return toDTO(repository.save(ordemServico));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Ordem de serviço não encontrada");
        }

        repository.deleteById(id);
    }


    private void preencherDados(
            OrdemServico ordemServico,
            OrdemServicoDTO dto) {


        ordemServico.setCliente(
                clienteRepository.findById(dto.getClienteId())
                        .orElseThrow(() -> new RuntimeException("Cliente não encontrado"))
        );


        ordemServico.setContrato(
                contratoRepository.findById(dto.getContratoId())
                        .orElseThrow(() -> new RuntimeException("Contrato não encontrado"))
        );


        ordemServico.setTipoServico(
                tipoServicoRepository.findById(dto.getTipoServicoId())
                        .orElseThrow(() -> new RuntimeException("Tipo de serviço não encontrado"))
        );


        if (dto.getDiagnosticoInicialId() != null) {

            ordemServico.setDiagnosticoInicial(
                    diagnosticoInicialRepository.findById(dto.getDiagnosticoInicialId())
                            .orElseThrow(() -> new RuntimeException("Diagnóstico inicial não encontrado"))
            );
        }


        ordemServico.setPrioridade(
                prioridadeRepository.findById(dto.getPrioridadeId())
                        .orElseThrow(() -> new RuntimeException("Prioridade não encontrada"))
        );


        ordemServico.setObservacao(dto.getObservacao());
        ordemServico.setDataAbertura(dto.getDataAbertura());


        ordemServico.setStatus(
                statusRepository.findById(dto.getStatusOrdemServicoId())
                        .orElseThrow(() -> new RuntimeException("Status da ordem de serviço não encontrado"))
        );
    }


    private OrdemServicoDTO toDTO(OrdemServico ordemServico) {

        OrdemServicoDTO dto = new OrdemServicoDTO();

        dto.setId(ordemServico.getId());

        dto.setContratoId(
                ordemServico.getContrato().getId()
        );

        dto.setTipoServicoId(
                ordemServico.getTipoServico().getId()
        );


        if (ordemServico.getDiagnosticoInicial() != null) {
            dto.setDiagnosticoInicialId(
                    ordemServico.getDiagnosticoInicial().getId()
            );
        }


        dto.setPrioridadeId(
                ordemServico.getPrioridade().getId()
        );
        
        dto.setClienteId(
        ordemServico.getCliente().getId()
);

        dto.setObservacao(
                ordemServico.getObservacao()
        );

        dto.setDataAbertura(
                ordemServico.getDataAbertura()
        );

        dto.setStatusOrdemServicoId(
                ordemServico.getStatus().getId()
        );

        return dto;
    }
}
