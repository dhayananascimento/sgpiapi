package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.DiagnosticoInicialDTO;
import com.example.sgpiapi.service.DiagnosticoInicialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/diagnosticos-iniciais")
public class DiagnosticoInicialController {

    @Autowired
    private DiagnosticoInicialService service;

    @PostMapping
    public ResponseEntity<DiagnosticoInicialDTO> salvar(@RequestBody DiagnosticoInicialDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<DiagnosticoInicialDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DiagnosticoInicialDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<DiagnosticoInicialDTO> atualizar(@PathVariable Long id,
                                                           @RequestBody DiagnosticoInicialDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}