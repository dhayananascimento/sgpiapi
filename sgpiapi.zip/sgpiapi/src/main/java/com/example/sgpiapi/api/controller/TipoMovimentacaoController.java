package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.TipoMovimentacaoDTO;
import com.example.sgpiapi.service.TipoMovimentacaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tipos-movimentacao")
public class TipoMovimentacaoController {

    @Autowired
    private TipoMovimentacaoService service;

    @PostMapping
    public ResponseEntity<TipoMovimentacaoDTO> salvar(@RequestBody TipoMovimentacaoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<TipoMovimentacaoDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoMovimentacaoDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TipoMovimentacaoDTO> atualizar(@PathVariable Long id,
                                                         @RequestBody TipoMovimentacaoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}
