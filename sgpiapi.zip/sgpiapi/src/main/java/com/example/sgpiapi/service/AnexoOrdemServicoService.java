package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.AnexoOrdemServicoDTO;
import com.example.sgpiapi.model.entity.AnexoOrdemServico;
import com.example.sgpiapi.model.entity.OrdemServico;
import com.example.sgpiapi.model.repository.AnexoOrdemServicoRepository;
import com.example.sgpiapi.model.repository.OrdemServicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AnexoOrdemServicoService {

    private final AnexoOrdemServicoRepository repository;
    private final OrdemServicoRepository ordemServicoRepository;


    public AnexoOrdemServicoService(
            AnexoOrdemServicoRepository repository,
            OrdemServicoRepository ordemServicoRepository) {

        this.repository = repository;
        this.ordemServicoRepository = ordemServicoRepository;
    }


    public List<AnexoOrdemServicoDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public AnexoOrdemServicoDTO buscarPorId(Long id) {

        AnexoOrdemServico anexo = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Anexo não encontrado"));

        return toDTO(anexo);
    }


    public AnexoOrdemServicoDTO salvar(AnexoOrdemServicoDTO dto) {

        AnexoOrdemServico anexo = new AnexoOrdemServico();

        preencherDados(anexo, dto);

        return toDTO(repository.save(anexo));
    }


    public AnexoOrdemServicoDTO atualizar(
            Long id,
            AnexoOrdemServicoDTO dto) {

        AnexoOrdemServico anexo = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Anexo não encontrado"));

        preencherDados(anexo, dto);

        return toDTO(repository.save(anexo));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Anexo não encontrado");
        }

        repository.deleteById(id);
    }


    private void preencherDados(
            AnexoOrdemServico anexo,
            AnexoOrdemServicoDTO dto) {


        OrdemServico ordemServico =
                ordemServicoRepository.findById(dto.getOrdemServicoId())
                        .orElseThrow(() ->
                                new RuntimeException("Ordem de serviço não encontrada"));


        anexo.setOrdemServico(ordemServico);
        anexo.setNomeArquivo(dto.getNomeArquivo());
        anexo.setTipoArquivo(dto.getTipoArquivo());
        anexo.setTamanhoArquivo(dto.getTamanhoArquivo());
        anexo.setCaminhoArquivo(dto.getCaminhoArquivo());
    }


    private AnexoOrdemServicoDTO toDTO(
            AnexoOrdemServico anexo) {

        AnexoOrdemServicoDTO dto = new AnexoOrdemServicoDTO();

        dto.setId(anexo.getId());

        dto.setOrdemServicoId(
                anexo.getOrdemServico().getId()
        );

        dto.setNomeArquivo(
                anexo.getNomeArquivo()
        );

        dto.setTipoArquivo(
                anexo.getTipoArquivo()
        );

        dto.setTamanhoArquivo(
                anexo.getTamanhoArquivo()
        );

        dto.setCaminhoArquivo(
                anexo.getCaminhoArquivo()
        );

        return dto;
    }
}