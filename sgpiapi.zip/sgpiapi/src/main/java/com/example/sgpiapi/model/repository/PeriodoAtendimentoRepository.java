package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.PeriodoAtendimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PeriodoAtendimentoRepository extends JpaRepository<PeriodoAtendimento, Long> {

}
