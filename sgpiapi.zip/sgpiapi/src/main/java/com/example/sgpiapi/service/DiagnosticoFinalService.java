package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.DiagnosticoFinalDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.DiagnosticoFinal;
import com.example.sgpiapi.model.repository.DiagnosticoFinalRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DiagnosticoFinalService {

    @Autowired
    private DiagnosticoFinalRepository repository;

    @Autowired
    private ModelMapper mapper;

    public DiagnosticoFinalDTO salvar(DiagnosticoFinalDTO dto) {

        DiagnosticoFinal diagnostico = mapper.map(dto, DiagnosticoFinal.class);

        diagnostico = repository.save(diagnostico);

        return mapper.map(diagnostico, DiagnosticoFinalDTO.class);
    }

    public List<DiagnosticoFinalDTO> listar() {

        return repository.findAll()
                .stream()
                .map(diagnostico -> mapper.map(diagnostico, DiagnosticoFinalDTO.class))
                .collect(Collectors.toList());
    }

    public DiagnosticoFinalDTO buscarPorId(Long id) {

        DiagnosticoFinal diagnostico = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Diagnóstico final não encontrado."));

        return mapper.map(diagnostico, DiagnosticoFinalDTO.class);
    }

    public DiagnosticoFinalDTO atualizar(Long id, DiagnosticoFinalDTO dto) {

        DiagnosticoFinal diagnostico = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Diagnóstico final não encontrado."));

        diagnostico.setNome(dto.getNome());

        repository.save(diagnostico);

        return mapper.map(diagnostico, DiagnosticoFinalDTO.class);
    }

    public void excluir(Long id) {

        DiagnosticoFinal diagnostico = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Diagnóstico final não encontrado."));

        repository.delete(diagnostico);
    }
}