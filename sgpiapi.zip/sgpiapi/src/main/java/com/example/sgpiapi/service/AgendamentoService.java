package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.AgendamentoDTO;
import com.example.sgpiapi.model.entity.Agendamento;
import com.example.sgpiapi.model.entity.OrdemServico;
import com.example.sgpiapi.model.entity.PeriodoAtendimento;
import com.example.sgpiapi.model.entity.Tecnico;
import com.example.sgpiapi.model.repository.AgendamentoRepository;
import com.example.sgpiapi.model.repository.OrdemServicoRepository;
import com.example.sgpiapi.model.repository.PeriodoAtendimentoRepository;
import com.example.sgpiapi.model.repository.TecnicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AgendamentoService {

    private final AgendamentoRepository repository;
    private final OrdemServicoRepository ordemServicoRepository;
    private final PeriodoAtendimentoRepository periodoRepository;
    private final TecnicoRepository tecnicoRepository;


    public AgendamentoService(
            AgendamentoRepository repository,
            OrdemServicoRepository ordemServicoRepository,
            PeriodoAtendimentoRepository periodoRepository,
            TecnicoRepository tecnicoRepository) {

        this.repository = repository;
        this.ordemServicoRepository = ordemServicoRepository;
        this.periodoRepository = periodoRepository;
        this.tecnicoRepository = tecnicoRepository;
    }


    public List<AgendamentoDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public AgendamentoDTO buscarPorId(Long id) {

        Agendamento agendamento = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Agendamento não encontrado"));

        return toDTO(agendamento);
    }


    public AgendamentoDTO salvar(AgendamentoDTO dto) {

        Agendamento agendamento = new Agendamento();

        preencherDados(agendamento, dto);

        return toDTO(repository.save(agendamento));
    }


    public AgendamentoDTO atualizar(Long id, AgendamentoDTO dto) {

        Agendamento agendamento = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Agendamento não encontrado"));

        preencherDados(agendamento, dto);

        return toDTO(repository.save(agendamento));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Agendamento não encontrado");
        }

        repository.deleteById(id);
    }


    private void preencherDados(
            Agendamento agendamento,
            AgendamentoDTO dto) {


        OrdemServico ordemServico =
                ordemServicoRepository.findById(dto.getOrdemServicoId())
                        .orElseThrow(() ->
                                new RuntimeException("Ordem de serviço não encontrada"));


        PeriodoAtendimento periodo =
                periodoRepository.findById(dto.getPeriodoAtendimentoId())
                        .orElseThrow(() ->
                                new RuntimeException("Período de atendimento não encontrado"));


        Tecnico tecnico =
                tecnicoRepository.findById(dto.getTecnicoId())
                        .orElseThrow(() ->
                                new RuntimeException("Técnico não encontrado"));


        agendamento.setOrdemServico(ordemServico);
        agendamento.setData(dto.getData());
        agendamento.setPeriodo(periodo);
        agendamento.setHoraInicial(dto.getHoraInicial());
        agendamento.setHoraFinal(dto.getHoraFinal());
        agendamento.setMotivoReagendamento(dto.getMotivoReagendamento());
        agendamento.setTecnicoResponsavel(tecnico);
    }


    private AgendamentoDTO toDTO(Agendamento agendamento) {

        AgendamentoDTO dto = new AgendamentoDTO();

        dto.setId(agendamento.getId());

        dto.setOrdemServicoId(
                agendamento.getOrdemServico().getId()
        );

        dto.setData(
                agendamento.getData()
        );

        dto.setPeriodoAtendimentoId(
                agendamento.getPeriodo().getId()
        );

        dto.setHoraInicial(
                agendamento.getHoraInicial()
        );

        dto.setHoraFinal(
                agendamento.getHoraFinal()
        );
	
	dto.setMotivoReagendamento(
        	agendamento.getMotivoReagendamento()
	);

        dto.setTecnicoId(
                agendamento.getTecnicoResponsavel().getId()
        );

        return dto;
    }
}