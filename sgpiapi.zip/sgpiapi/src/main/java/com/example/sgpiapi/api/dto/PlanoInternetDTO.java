package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlanoInternetDTO {

    private Long id;
    private String nome;
    private Integer velocidadeMbps;
    private BigDecimal valorMensal;

}
