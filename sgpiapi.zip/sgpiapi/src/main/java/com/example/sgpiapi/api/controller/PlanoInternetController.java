package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.PlanoInternetDTO;
import com.example.sgpiapi.service.PlanoInternetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/planos-internet")
public class PlanoInternetController {

    @Autowired
    private PlanoInternetService service;

    @PostMapping
    public ResponseEntity<PlanoInternetDTO> salvar(@RequestBody PlanoInternetDTO dto){

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<PlanoInternetDTO>> listar(){

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PlanoInternetDTO> buscarPorId(@PathVariable Long id){

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PlanoInternetDTO> atualizar(@PathVariable Long id,
                                                      @RequestBody PlanoInternetDTO dto){

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id){

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}
