package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.TipoRegistroOrdemServico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TipoRegistroOrdemServicoRepository extends JpaRepository<TipoRegistroOrdemServico, Long> {

}
