package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.PeriodoAtendimentoDTO;
import com.example.sgpiapi.service.PeriodoAtendimentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/periodos-atendimento")
public class PeriodoAtendimentoController {

    @Autowired
    private PeriodoAtendimentoService service;

    @PostMapping
    public ResponseEntity<PeriodoAtendimentoDTO> salvar(@RequestBody PeriodoAtendimentoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<PeriodoAtendimentoDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PeriodoAtendimentoDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PeriodoAtendimentoDTO> atualizar(@PathVariable Long id,
                                                           @RequestBody PeriodoAtendimentoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}
