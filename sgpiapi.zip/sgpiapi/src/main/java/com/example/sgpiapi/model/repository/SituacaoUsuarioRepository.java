package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.SituacaoUsuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SituacaoUsuarioRepository extends JpaRepository<SituacaoUsuario, Long> {

}
