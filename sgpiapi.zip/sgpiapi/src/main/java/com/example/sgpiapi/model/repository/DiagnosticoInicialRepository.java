package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.DiagnosticoInicial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DiagnosticoInicialRepository extends JpaRepository<DiagnosticoInicial, Long> {

}
