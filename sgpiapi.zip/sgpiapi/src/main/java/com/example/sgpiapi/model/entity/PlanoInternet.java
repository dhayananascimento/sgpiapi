package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "plano_internet")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlanoInternet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private Integer velocidadeMbps;

    @Column(nullable = false)
    private BigDecimal valorMensal;
}