package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.StatusAtendimentoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.StatusAtendimento;
import com.example.sgpiapi.model.repository.StatusAtendimentoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StatusAtendimentoService {

    @Autowired
    private StatusAtendimentoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public StatusAtendimentoDTO salvar(StatusAtendimentoDTO dto) {

        StatusAtendimento status = mapper.map(dto, StatusAtendimento.class);

        status = repository.save(status);

        return mapper.map(status, StatusAtendimentoDTO.class);
    }

    public List<StatusAtendimentoDTO> listar() {

        return repository.findAll()
                .stream()
                .map(status -> mapper.map(status, StatusAtendimentoDTO.class))
                .collect(Collectors.toList());
    }

    public StatusAtendimentoDTO buscarPorId(Long id) {

        StatusAtendimento status = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Status do atendimento não encontrado."));

        return mapper.map(status, StatusAtendimentoDTO.class);
    }

    public StatusAtendimentoDTO atualizar(Long id, StatusAtendimentoDTO dto) {

        StatusAtendimento status = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Status do atendimento não encontrado."));

        status.setNome(dto.getNome());
        status.setDescricao(dto.getDescricao());

        repository.save(status);

        return mapper.map(status, StatusAtendimentoDTO.class);
    }

    public void excluir(Long id) {

        StatusAtendimento status = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Status do atendimento não encontrado."));

        repository.delete(status);
    }
}