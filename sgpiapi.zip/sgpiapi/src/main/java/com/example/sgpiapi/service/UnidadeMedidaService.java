package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.UnidadeMedidaDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.UnidadeMedida;
import com.example.sgpiapi.model.repository.UnidadeMedidaRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UnidadeMedidaService {

    @Autowired
    private UnidadeMedidaRepository repository;

    @Autowired
    private ModelMapper mapper;

    public UnidadeMedidaDTO salvar(UnidadeMedidaDTO dto) {

        UnidadeMedida entity = mapper.map(dto, UnidadeMedida.class);

        entity = repository.save(entity);

        return mapper.map(entity, UnidadeMedidaDTO.class);
    }

    public List<UnidadeMedidaDTO> listar() {

        return repository.findAll()
                .stream()
                .map(entity -> mapper.map(entity, UnidadeMedidaDTO.class))
                .collect(Collectors.toList());
    }

    public UnidadeMedidaDTO buscarPorId(Long id) {

        UnidadeMedida entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Unidade de medida não encontrada."));

        return mapper.map(entity, UnidadeMedidaDTO.class);
    }

    public UnidadeMedidaDTO atualizar(Long id, UnidadeMedidaDTO dto) {

        UnidadeMedida entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Unidade de medida não encontrada."));

        entity.setNome(dto.getNome());
        entity.setSigla(dto.getSigla());

        repository.save(entity);

        return mapper.map(entity, UnidadeMedidaDTO.class);
    }

    public void excluir(Long id) {

        UnidadeMedida entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Unidade de medida não encontrada."));

        repository.delete(entity);
    }

}
