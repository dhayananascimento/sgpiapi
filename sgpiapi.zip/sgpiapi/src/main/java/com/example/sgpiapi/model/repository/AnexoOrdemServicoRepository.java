package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.AnexoOrdemServico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AnexoOrdemServicoRepository extends JpaRepository<AnexoOrdemServico, Long> {

}
