package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.SituacaoClienteDTO;
import com.example.sgpiapi.service.SituacaoClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/situacoes-clientes")
public class SituacaoClienteController {

    @Autowired
    private SituacaoClienteService service;


    @PostMapping
    public ResponseEntity<SituacaoClienteDTO> salvar(@RequestBody SituacaoClienteDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @GetMapping
    public ResponseEntity<List<SituacaoClienteDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }


    @GetMapping("/{id}")
    public ResponseEntity<SituacaoClienteDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PutMapping("/{id}")
    public ResponseEntity<SituacaoClienteDTO> atualizar(@PathVariable Long id,
                                                        @RequestBody SituacaoClienteDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}