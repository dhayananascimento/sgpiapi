package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.TipoAtendimentoDTO;
import com.example.sgpiapi.service.TipoAtendimentoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tipo-atendimento")
public class TipoAtendimentoController {

    private final TipoAtendimentoService service;

    public TipoAtendimentoController(TipoAtendimentoService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<TipoAtendimentoDTO>> listarTodos() {
        return ResponseEntity.ok(service.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoAtendimentoDTO> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PostMapping
    public ResponseEntity<TipoAtendimentoDTO> salvar(
            @RequestBody TipoAtendimentoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TipoAtendimentoDTO> atualizar(
            @PathVariable Long id,
            @RequestBody TipoAtendimentoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}