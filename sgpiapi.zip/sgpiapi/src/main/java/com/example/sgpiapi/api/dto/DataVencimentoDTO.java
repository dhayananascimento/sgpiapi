package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataVencimentoDTO {

    private Long id;
    private Integer diaNumerico;
    private String diaExtenso;

}
