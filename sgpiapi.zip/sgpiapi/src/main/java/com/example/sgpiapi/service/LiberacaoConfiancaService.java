package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.LiberacaoConfiancaDTO;
import com.example.sgpiapi.model.entity.Contrato;
import com.example.sgpiapi.model.entity.LiberacaoConfianca;
import com.example.sgpiapi.model.entity.Usuario;
import com.example.sgpiapi.model.repository.ContratoRepository;
import com.example.sgpiapi.model.repository.LiberacaoConfiancaRepository;
import com.example.sgpiapi.model.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class LiberacaoConfiancaService {

    private final LiberacaoConfiancaRepository repository;
    private final ContratoRepository contratoRepository;
    private final UsuarioRepository usuarioRepository;


    public LiberacaoConfiancaService(
            LiberacaoConfiancaRepository repository,
            ContratoRepository contratoRepository,
            UsuarioRepository usuarioRepository) {

        this.repository = repository;
        this.contratoRepository = contratoRepository;
        this.usuarioRepository = usuarioRepository;
    }


    public List<LiberacaoConfiancaDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public LiberacaoConfiancaDTO buscarPorId(Long id) {

        LiberacaoConfianca liberacao = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Liberação de confiança não encontrada"));

        return toDTO(liberacao);
    }


    public LiberacaoConfiancaDTO salvar(LiberacaoConfiancaDTO dto) {

        LiberacaoConfianca liberacao = new LiberacaoConfianca();

        preencherDados(liberacao, dto);

        return toDTO(repository.save(liberacao));
    }


    public LiberacaoConfiancaDTO atualizar(
            Long id,
            LiberacaoConfiancaDTO dto) {

        LiberacaoConfianca liberacao = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Liberação de confiança não encontrada"));

        preencherDados(liberacao, dto);

        return toDTO(repository.save(liberacao));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Liberação de confiança não encontrada");
        }

        repository.deleteById(id);
    }


    private void preencherDados(
            LiberacaoConfianca liberacao,
            LiberacaoConfiancaDTO dto) {


        Contrato contrato =
                contratoRepository.findById(dto.getContratoId())
                        .orElseThrow(() ->
                                new RuntimeException("Contrato não encontrado"));


        Usuario usuario =
                usuarioRepository.findById(dto.getUsuarioResponsavelId())
                        .orElseThrow(() ->
                                new RuntimeException("Usuário responsável não encontrado"));


        liberacao.setContrato(contrato);

        /*
         * A entidade utiliza LocalDateTime,
         * enquanto o DTO enviado possui LocalDate.
         * O horário é iniciado em zero conforme a estrutura atual.
         */
        if (dto.getDataInicio() != null) {
            liberacao.setDataInicio(dto.getDataInicio());
        }

        if (dto.getDataFim() != null) {
            liberacao.setDataFim(dto.getDataFim());
        }

        liberacao.setObservacao(dto.getObservacao());
        liberacao.setUsuarioResponsavel(usuario);
    }


    private LiberacaoConfiancaDTO toDTO(
            LiberacaoConfianca liberacao) {

        LiberacaoConfiancaDTO dto =
                new LiberacaoConfiancaDTO();

        dto.setId(liberacao.getId());

        dto.setContratoId(
                liberacao.getContrato().getId()
        );


	dto.setDataInicio(liberacao.getDataInicio());
	dto.setDataFim(liberacao.getDataFim());

        dto.setObservacao(
                liberacao.getObservacao()
        );

        dto.setUsuarioResponsavelId(
                liberacao.getUsuarioResponsavel().getId()
        );

        return dto;
    }
}
