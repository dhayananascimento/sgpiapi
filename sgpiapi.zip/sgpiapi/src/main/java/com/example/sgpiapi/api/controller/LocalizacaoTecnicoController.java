package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.LocalizacaoTecnicoDTO;
import com.example.sgpiapi.service.LocalizacaoTecnicoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/localizacao-tecnico")
public class LocalizacaoTecnicoController {

    private final LocalizacaoTecnicoService service;


    public LocalizacaoTecnicoController(
            LocalizacaoTecnicoService service) {

        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<LocalizacaoTecnicoDTO>> listarTodos() {

        return ResponseEntity.ok(service.listarTodos());
    }


    @GetMapping("/{id}")
    public ResponseEntity<LocalizacaoTecnicoDTO> buscarPorId(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PostMapping
    public ResponseEntity<LocalizacaoTecnicoDTO> salvar(
            @RequestBody LocalizacaoTecnicoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @PutMapping("/{id}")
    public ResponseEntity<LocalizacaoTecnicoDTO> atualizar(
            @PathVariable Long id,
            @RequestBody LocalizacaoTecnicoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}