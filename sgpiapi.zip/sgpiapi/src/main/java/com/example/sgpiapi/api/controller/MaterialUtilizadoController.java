package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.MaterialUtilizadoDTO;
import com.example.sgpiapi.service.MaterialUtilizadoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/material-utilizado")
public class MaterialUtilizadoController {

    private final MaterialUtilizadoService service;


    public MaterialUtilizadoController(
            MaterialUtilizadoService service) {

        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<MaterialUtilizadoDTO>> listarTodos() {

        return ResponseEntity.ok(service.listarTodos());
    }


    @GetMapping("/{id}")
    public ResponseEntity<MaterialUtilizadoDTO> buscarPorId(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PostMapping
    public ResponseEntity<MaterialUtilizadoDTO> salvar(
            @RequestBody MaterialUtilizadoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @PutMapping("/{id}")
    public ResponseEntity<MaterialUtilizadoDTO> atualizar(
            @PathVariable Long id,
            @RequestBody MaterialUtilizadoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}