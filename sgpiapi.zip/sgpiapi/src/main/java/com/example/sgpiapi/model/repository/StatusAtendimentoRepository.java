package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.StatusAtendimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StatusAtendimentoRepository extends JpaRepository<StatusAtendimento, Long> {

}
