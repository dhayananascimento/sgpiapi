package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.RegistroOrdemServicoDTO;
import com.example.sgpiapi.model.entity.*;
import com.example.sgpiapi.model.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RegistroOrdemServicoService {

    private final RegistroOrdemServicoRepository repository;
    private final OrdemServicoRepository ordemServicoRepository;
    private final TipoRegistroOrdemServicoRepository tipoRegistroRepository;
    private final DiagnosticoFinalRepository diagnosticoFinalRepository;
    private final UsuarioRepository usuarioRepository;


    public RegistroOrdemServicoService(
            RegistroOrdemServicoRepository repository,
            OrdemServicoRepository ordemServicoRepository,
            TipoRegistroOrdemServicoRepository tipoRegistroRepository,
            DiagnosticoFinalRepository diagnosticoFinalRepository,
            UsuarioRepository usuarioRepository) {

        this.repository = repository;
        this.ordemServicoRepository = ordemServicoRepository;
        this.tipoRegistroRepository = tipoRegistroRepository;
        this.diagnosticoFinalRepository = diagnosticoFinalRepository;
        this.usuarioRepository = usuarioRepository;
    }


    public List<RegistroOrdemServicoDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public RegistroOrdemServicoDTO buscarPorId(Long id) {

        RegistroOrdemServico registro = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Registro de ordem de serviço não encontrado"));

        return toDTO(registro);
    }


    public RegistroOrdemServicoDTO salvar(RegistroOrdemServicoDTO dto) {

        RegistroOrdemServico registro = new RegistroOrdemServico();

        preencherDados(registro, dto);

        return toDTO(repository.save(registro));
    }


    public RegistroOrdemServicoDTO atualizar(Long id, RegistroOrdemServicoDTO dto) {

        RegistroOrdemServico registro = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Registro de ordem de serviço não encontrado"));

        preencherDados(registro, dto);

        return toDTO(repository.save(registro));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Registro de ordem de serviço não encontrado");
        }

        repository.deleteById(id);
    }
    
    private void preencherDados(
        RegistroOrdemServico registro,
        RegistroOrdemServicoDTO dto) {

    OrdemServico ordemServico =
            ordemServicoRepository.findById(dto.getOrdemServicoId())
                    .orElseThrow(() ->
                            new RuntimeException("Ordem de serviço não encontrada"));

    TipoRegistroOrdemServico tipoRegistro =
            tipoRegistroRepository.findById(dto.getTipoRegistroId())
                    .orElseThrow(() ->
                            new RuntimeException("Tipo de registro não encontrado"));

    Usuario usuario =
            usuarioRepository.findById(dto.getUsuarioResponsavelId())
                    .orElseThrow(() ->
                            new RuntimeException("Usuário não encontrado"));

    registro.setOrdemServico(ordemServico);
    registro.setTipoRegistro(tipoRegistro);
    registro.setDescricao(dto.getDescricao());
    registro.setDataHora(dto.getDataHora());
    registro.setUsuario(usuario);

    if (dto.getDiagnosticoFinalId() != null) {

        DiagnosticoFinal diagnosticoFinal =
                diagnosticoFinalRepository.findById(dto.getDiagnosticoFinalId())
                        .orElseThrow(() ->
                                new RuntimeException("Diagnóstico final não encontrado"));

        registro.setDiagnosticoFinal(diagnosticoFinal);

    } else {

        registro.setDiagnosticoFinal(null);
    }
}

private RegistroOrdemServicoDTO toDTO(
        RegistroOrdemServico registro) {

    RegistroOrdemServicoDTO dto =
            new RegistroOrdemServicoDTO();

    dto.setId(registro.getId());
    dto.setOrdemServicoId(registro.getOrdemServico().getId());
    dto.setTipoRegistroId(registro.getTipoRegistro().getId());
    dto.setDescricao(registro.getDescricao());
    dto.setDataHora(registro.getDataHora());
    dto.setUsuarioResponsavelId(registro.getUsuario().getId());

    if (registro.getDiagnosticoFinal() != null) {
        dto.setDiagnosticoFinalId(
                registro.getDiagnosticoFinal().getId()
        );
    }

    return dto;
}
}
