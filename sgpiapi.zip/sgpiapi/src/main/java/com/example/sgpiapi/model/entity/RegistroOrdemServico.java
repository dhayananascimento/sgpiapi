package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "registro_ordem_servico")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegistroOrdemServico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ordem_servico_id", nullable = false)
    private OrdemServico ordemServico;

    @ManyToOne
    @JoinColumn(name = "tipo_registro_id", nullable = false)
    private TipoRegistroOrdemServico tipoRegistro;

    @Column(length = 2000)
    private String descricao;

    @ManyToOne
    @JoinColumn(name = "diagnostico_final_id")
    private DiagnosticoFinal diagnosticoFinal;

    @Column(nullable = false)
    private LocalDateTime dataHora;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;
}