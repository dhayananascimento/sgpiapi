package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.ClientePessoaFisicaDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Cliente;
import com.example.sgpiapi.model.entity.ClientePessoaFisica;
import com.example.sgpiapi.model.entity.SituacaoCliente;
import com.example.sgpiapi.model.repository.ClienteRepository;
import com.example.sgpiapi.model.repository.SituacaoClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClientePessoaFisicaService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private SituacaoClienteRepository situacaoClienteRepository;


    public ClientePessoaFisicaDTO salvar(ClientePessoaFisicaDTO dto) {

        SituacaoCliente situacao = situacaoClienteRepository.findById(dto.getSituacaoClienteId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do cliente não encontrada."));

        ClientePessoaFisica cliente = new ClientePessoaFisica();

        cliente.setTelefone(dto.getTelefone());
        cliente.setEmail(dto.getEmail());
        cliente.setDataRegistro(dto.getDataRegistro());
        cliente.setSituacaoCliente(situacao);

        cliente.setNomeCompleto(dto.getNomeCompleto());
        cliente.setCpf(dto.getCpf());
        cliente.setBrasileiro(dto.getBrasileiro());

        cliente = (ClientePessoaFisica) clienteRepository.save(cliente);

        return converterParaDTO(cliente);
    }


    public List<ClientePessoaFisicaDTO> listar() {

        return clienteRepository.findAll()
                .stream()
                .filter(cliente -> cliente instanceof ClientePessoaFisica)
                .map(cliente -> converterParaDTO((ClientePessoaFisica) cliente))
                .collect(Collectors.toList());
    }


    public ClientePessoaFisicaDTO buscarPorId(Long id) {

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Cliente pessoa física não encontrado."));

        if (!(cliente instanceof ClientePessoaFisica)) {
            throw new ObjetoNaoEncontradoException("Cliente pessoa física não encontrado.");
        }

        ClientePessoaFisica clientePF = (ClientePessoaFisica) cliente;

        return converterParaDTO(clientePF);
    }


    public ClientePessoaFisicaDTO atualizar(Long id, ClientePessoaFisicaDTO dto) {

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Cliente pessoa física não encontrado."));

        if (!(cliente instanceof ClientePessoaFisica)) {
            throw new ObjetoNaoEncontradoException("Cliente pessoa física não encontrado.");
        }

        ClientePessoaFisica clientePF = (ClientePessoaFisica) cliente;

        SituacaoCliente situacao = situacaoClienteRepository.findById(dto.getSituacaoClienteId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do cliente não encontrada."));


        clientePF.setTelefone(dto.getTelefone());
        clientePF.setEmail(dto.getEmail());
        clientePF.setDataRegistro(dto.getDataRegistro());
        clientePF.setSituacaoCliente(situacao);

        clientePF.setNomeCompleto(dto.getNomeCompleto());
        clientePF.setCpf(dto.getCpf());
        clientePF.setBrasileiro(dto.getBrasileiro());

        clienteRepository.save(clientePF);

        return converterParaDTO(clientePF);
    }


    public void excluir(Long id) {

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Cliente pessoa física não encontrado."));

        if (!(cliente instanceof ClientePessoaFisica)) {
            throw new ObjetoNaoEncontradoException("Cliente pessoa física não encontrado.");
        }

        clienteRepository.delete(cliente);
    }


    private ClientePessoaFisicaDTO converterParaDTO(ClientePessoaFisica cliente) {

        ClientePessoaFisicaDTO dto = new ClientePessoaFisicaDTO();

        dto.setId(cliente.getId());
        dto.setTelefone(cliente.getTelefone());
        dto.setEmail(cliente.getEmail());
        dto.setDataRegistro(cliente.getDataRegistro());
        dto.setSituacaoClienteId(cliente.getSituacaoCliente().getId());

        dto.setNomeCompleto(cliente.getNomeCompleto());
        dto.setCpf(cliente.getCpf());
        dto.setBrasileiro(cliente.getBrasileiro());

        return dto;
    }

}