package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.LiberacaoConfiancaDTO;
import com.example.sgpiapi.service.LiberacaoConfiancaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/liberacao-confianca")
public class LiberacaoConfiancaController {

    private final LiberacaoConfiancaService service;


    public LiberacaoConfiancaController(
            LiberacaoConfiancaService service) {

        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<LiberacaoConfiancaDTO>> listarTodos() {

        return ResponseEntity.ok(service.listarTodos());
    }


    @GetMapping("/{id}")
    public ResponseEntity<LiberacaoConfiancaDTO> buscarPorId(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PostMapping
    public ResponseEntity<LiberacaoConfiancaDTO> salvar(
            @RequestBody LiberacaoConfiancaDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @PutMapping("/{id}")
    public ResponseEntity<LiberacaoConfiancaDTO> atualizar(
            @PathVariable Long id,
            @RequestBody LiberacaoConfiancaDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}