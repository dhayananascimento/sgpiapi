package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.StatusOrdemServicoDTO;
import com.example.sgpiapi.service.StatusOrdemServicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/status-ordens-servico")
public class StatusOrdemServicoController {

    @Autowired
    private StatusOrdemServicoService service;

    @PostMapping
    public ResponseEntity<StatusOrdemServicoDTO> salvar(@RequestBody StatusOrdemServicoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<StatusOrdemServicoDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<StatusOrdemServicoDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<StatusOrdemServicoDTO> atualizar(@PathVariable Long id,
                                                           @RequestBody StatusOrdemServicoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }

}