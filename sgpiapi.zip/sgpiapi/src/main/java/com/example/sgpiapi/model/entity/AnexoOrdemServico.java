package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "anexo_ordem_servico")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnexoOrdemServico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ordem_servico_id", nullable = false)
    private OrdemServico ordemServico;

    @Column(nullable = false)
    private String nomeArquivo;

    @Column(nullable = false)
    private String caminhoArquivo;

    @Column(nullable = false)
    private String tipoArquivo;

    @Column(nullable = false)
    private Long tamanhoArquivo;
}