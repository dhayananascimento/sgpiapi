package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AtendimentoDTO {

    private Long id;
    private Long contratoId;
    private Long tipoAtendimentoId;
    private String descricao;
    private LocalDateTime dataHora;
    private Long statusAtendimentoId;
    private Long atendenteId;

}
