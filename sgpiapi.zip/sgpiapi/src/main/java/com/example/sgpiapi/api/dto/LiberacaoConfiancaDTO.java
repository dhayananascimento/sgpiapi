package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LiberacaoConfiancaDTO {

    private Long id;
    private Long contratoId;
    private LocalDate dataInicio;
    private LocalDate dataFim;
    private String observacao;
    private Long usuarioResponsavelId;

}
