package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LiberacaoConfiancaDTO {

    private Long id;
    private Long contratoId;
    private LocalDateTime dataInicio;
    private LocalDateTime dataFim;
    private String observacao;
    private Long usuarioResponsavelId;

}
