package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegistroOrdemServicoDTO {

    private Long id;
    private Long ordemServicoId;
    private Long tipoRegistroId;
    private String descricao;
    private LocalDateTime dataHora;
    private Long usuarioResponsavelId;
    private Long diagnosticoFinalId;

}
