package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.AtendenteDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Atendente;
import com.example.sgpiapi.model.entity.SituacaoUsuario;
import com.example.sgpiapi.model.entity.Usuario;
import com.example.sgpiapi.model.repository.SituacaoUsuarioRepository;
import com.example.sgpiapi.model.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AtendenteService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private SituacaoUsuarioRepository situacaoUsuarioRepository;

    public AtendenteDTO salvar(AtendenteDTO dto) {

        SituacaoUsuario situacao = situacaoUsuarioRepository.findById(dto.getSituacaoUsuarioId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        Atendente atendente = new Atendente();

        atendente.setNomeCompleto(dto.getNomeCompleto());
        atendente.setCpf(dto.getCpf());
        atendente.setEmail(dto.getEmail());
        atendente.setSenha(dto.getSenha());
        atendente.setDataRegistro(dto.getDataRegistro());
        atendente.setSituacaoUsuario(situacao);

        atendente = usuarioRepository.save(atendente);

        return converterParaDTO(atendente);
    }

    public List<AtendenteDTO> listar() {

        return usuarioRepository.findAll()
                .stream()
                .filter(usuario -> usuario instanceof Atendente)
                .map(usuario -> converterParaDTO((Atendente) usuario))
                .collect(Collectors.toList());
    }

    public AtendenteDTO buscarPorId(Long id) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Atendente não encontrado."));

        if (!(usuario instanceof Atendente)) {
            throw new ObjetoNaoEncontradoException("Atendente não encontrado.");
        }

        Atendente atendente = (Atendente) usuario;

        return converterParaDTO(atendente);
    }

    public AtendenteDTO atualizar(Long id, AtendenteDTO dto) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Atendente não encontrado."));

        if (!(usuario instanceof Atendente)) {
            throw new ObjetoNaoEncontradoException("Atendente não encontrado.");
        }

        Atendente atendente = (Atendente) usuario;

        SituacaoUsuario situacao = situacaoUsuarioRepository.findById(dto.getSituacaoUsuarioId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        atendente.setNomeCompleto(dto.getNomeCompleto());
        atendente.setCpf(dto.getCpf());
        atendente.setEmail(dto.getEmail());
        atendente.setSenha(dto.getSenha());
        atendente.setDataRegistro(dto.getDataRegistro());
        atendente.setSituacaoUsuario(situacao);

        usuarioRepository.save(atendente);

        return converterParaDTO(atendente);
    }

    public void excluir(Long id) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Atendente não encontrado."));

        if (!(usuario instanceof Atendente)) {
            throw new ObjetoNaoEncontradoException("Atendente não encontrado.");
        }

        usuarioRepository.delete(usuario);
    }

    private AtendenteDTO converterParaDTO(Atendente atendente) {

        AtendenteDTO dto = new AtendenteDTO();

        dto.setId(atendente.getId());
        dto.setNomeCompleto(atendente.getNomeCompleto());
        dto.setCpf(atendente.getCpf());
        dto.setEmail(atendente.getEmail());
        dto.setSenha(atendente.getSenha());
        dto.setDataRegistro(atendente.getDataRegistro());
        dto.setSituacaoUsuarioId(atendente.getSituacaoUsuario().getId());

        return dto;
    }
}