package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.ContratoDTO;
import com.example.sgpiapi.model.entity.*;
import com.example.sgpiapi.model.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContratoService {

    private final ContratoRepository repository;
    private final ClienteRepository clienteRepository;
    private final PlanoInternetRepository planoInternetRepository;
    private final EnderecoRepository enderecoRepository;
    private final DataVencimentoRepository dataVencimentoRepository;
    private final SituacaoContratoRepository situacaoContratoRepository;


    public ContratoService(
            ContratoRepository repository,
            ClienteRepository clienteRepository,
            PlanoInternetRepository planoInternetRepository,
            EnderecoRepository enderecoRepository,
            DataVencimentoRepository dataVencimentoRepository,
            SituacaoContratoRepository situacaoContratoRepository) {

        this.repository = repository;
        this.clienteRepository = clienteRepository;
        this.planoInternetRepository = planoInternetRepository;
        this.enderecoRepository = enderecoRepository;
        this.dataVencimentoRepository = dataVencimentoRepository;
        this.situacaoContratoRepository = situacaoContratoRepository;
    }


    public List<ContratoDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public ContratoDTO buscarPorId(Long id) {

        Contrato contrato = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Contrato não encontrado"));

        return toDTO(contrato);
    }


    public ContratoDTO salvar(ContratoDTO dto) {

        Contrato contrato = new Contrato();

        preencherDados(contrato, dto);

        return toDTO(repository.save(contrato));
    }


    public ContratoDTO atualizar(Long id, ContratoDTO dto) {

        Contrato contrato = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Contrato não encontrado"));

        preencherDados(contrato, dto);

        return toDTO(repository.save(contrato));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Contrato não encontrado");
        }

        repository.deleteById(id);
    }


    private void preencherDados(
            Contrato contrato,
            ContratoDTO dto) {


        contrato.setCliente(
                clienteRepository.findById(dto.getClienteId())
                        .orElseThrow(() -> new RuntimeException("Cliente não encontrado"))
        );


        contrato.setPlanoInternet(
                planoInternetRepository.findById(dto.getPlanoInternetId())
                        .orElseThrow(() -> new RuntimeException("Plano de internet não encontrado"))
        );


        contrato.setEndereco(
                enderecoRepository.findById(dto.getEnderecoId())
                        .orElseThrow(() -> new RuntimeException("Endereço não encontrado"))
        );


        contrato.setDataAtivacao(dto.getDataAtivacao());


        contrato.setDataVencimento(
                dataVencimentoRepository.findById(dto.getDataVencimentoId())
                        .orElseThrow(() -> new RuntimeException("Data de vencimento não encontrada"))
        );


        contrato.setSituacaoContrato(
                situacaoContratoRepository.findById(dto.getSituacaoContratoId())
                        .orElseThrow(() -> new RuntimeException("Situação do contrato não encontrada"))
        );


        contrato.setObservacao(dto.getObservacao());
    }


    private ContratoDTO toDTO(Contrato contrato) {

        ContratoDTO dto = new ContratoDTO();

        dto.setId(contrato.getId());

        dto.setClienteId(
                contrato.getCliente().getId()
        );

        dto.setPlanoInternetId(
                contrato.getPlanoInternet().getId()
        );

        dto.setEnderecoId(
                contrato.getEndereco().getId()
        );

        dto.setDataAtivacao(
                contrato.getDataAtivacao()
        );

        dto.setDataVencimentoId(
                contrato.getDataVencimento().getId()
        );

        dto.setSituacaoContratoId(
                contrato.getSituacaoContrato().getId()
        );

        dto.setObservacao(
                contrato.getObservacao()
        );

        return dto;
    }
}