package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.StatusOrdemServicoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.StatusOrdemServico;
import com.example.sgpiapi.model.repository.StatusOrdemServicoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StatusOrdemServicoService {

    @Autowired
    private StatusOrdemServicoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public StatusOrdemServicoDTO salvar(StatusOrdemServicoDTO dto) {

        StatusOrdemServico status = mapper.map(dto, StatusOrdemServico.class);

        status = repository.save(status);

        return mapper.map(status, StatusOrdemServicoDTO.class);
    }

    public List<StatusOrdemServicoDTO> listar() {

        return repository.findAll()
                .stream()
                .map(status -> mapper.map(status, StatusOrdemServicoDTO.class))
                .collect(Collectors.toList());
    }

    public StatusOrdemServicoDTO buscarPorId(Long id) {

        StatusOrdemServico status = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Status da ordem de serviço não encontrado."));

        return mapper.map(status, StatusOrdemServicoDTO.class);
    }

    public StatusOrdemServicoDTO atualizar(Long id, StatusOrdemServicoDTO dto) {

        StatusOrdemServico status = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Status da ordem de serviço não encontrado."));

        status.setNome(dto.getNome());

        repository.save(status);

        return mapper.map(status, StatusOrdemServicoDTO.class);
    }

    public void excluir(Long id) {

        StatusOrdemServico status = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Status da ordem de serviço não encontrado."));

        repository.delete(status);
    }

}