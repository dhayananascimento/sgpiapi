package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.TipoServicoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.TipoServico;
import com.example.sgpiapi.model.repository.TipoServicoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TipoServicoService {

    @Autowired
    private TipoServicoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public TipoServicoDTO salvar(TipoServicoDTO dto) {

        TipoServico entity = mapper.map(dto, TipoServico.class);

        entity = repository.save(entity);

        return mapper.map(entity, TipoServicoDTO.class);
    }

    public List<TipoServicoDTO> listar() {

        return repository.findAll()
                .stream()
                .map(entity -> mapper.map(entity, TipoServicoDTO.class))
                .collect(Collectors.toList());
    }

    public TipoServicoDTO buscarPorId(Long id) {

        TipoServico entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Tipo de serviço não encontrado."));

        return mapper.map(entity, TipoServicoDTO.class);
    }

    public TipoServicoDTO atualizar(Long id, TipoServicoDTO dto) {

        TipoServico entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Tipo de serviço não encontrado."));

        entity.setNome(dto.getNome());
        entity.setPreco(dto.getPreco());
        entity.setPossuiFidelidade(dto.getPossuiFidelidade());
        entity.setPeriodoFidelidadeMeses(dto.getPeriodoFidelidadeMeses());

        repository.save(entity);

        return mapper.map(entity, TipoServicoDTO.class);
    }

    public void excluir(Long id) {

        TipoServico entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Tipo de serviço não encontrado."));

        repository.delete(entity);
    }

}
