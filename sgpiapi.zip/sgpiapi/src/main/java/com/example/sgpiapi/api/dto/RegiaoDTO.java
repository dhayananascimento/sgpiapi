package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegiaoDTO {

    private Long id;
    private String nome;
    private String sigla;

}
