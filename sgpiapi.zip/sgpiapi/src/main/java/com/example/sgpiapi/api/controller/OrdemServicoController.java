package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.OrdemServicoDTO;
import com.example.sgpiapi.service.OrdemServicoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ordem-servico")
public class OrdemServicoController {

    private final OrdemServicoService service;


    public OrdemServicoController(OrdemServicoService service) {
        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<OrdemServicoDTO>> listarTodos() {

        return ResponseEntity.ok(service.listarTodos());
    }


    @GetMapping("/{id}")
    public ResponseEntity<OrdemServicoDTO> buscarPorId(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PostMapping
    public ResponseEntity<OrdemServicoDTO> salvar(
            @RequestBody OrdemServicoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @PutMapping("/{id}")
    public ResponseEntity<OrdemServicoDTO> atualizar(
            @PathVariable Long id,
            @RequestBody OrdemServicoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}