package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.ClientePessoaJuridicaDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Cliente;
import com.example.sgpiapi.model.entity.ClientePessoaJuridica;
import com.example.sgpiapi.model.entity.SituacaoCliente;
import com.example.sgpiapi.model.repository.ClienteRepository;
import com.example.sgpiapi.model.repository.SituacaoClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClientePessoaJuridicaService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private SituacaoClienteRepository situacaoClienteRepository;


    public ClientePessoaJuridicaDTO salvar(ClientePessoaJuridicaDTO dto) {

        SituacaoCliente situacao = situacaoClienteRepository.findById(dto.getSituacaoClienteId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do cliente não encontrada."));

        ClientePessoaJuridica cliente = new ClientePessoaJuridica();

        cliente.setTelefone(dto.getTelefone());
        cliente.setEmail(dto.getEmail());
        cliente.setDataRegistro(dto.getDataRegistro());
        cliente.setSituacaoCliente(situacao);

        cliente.setRazaoSocial(dto.getRazaoSocial());
        cliente.setCnpj(dto.getCnpj());
        cliente.setNomeResponsavel(dto.getNomeResponsavel());
        cliente.setCpfResponsavel(dto.getCpfResponsavel());

        cliente = (ClientePessoaJuridica) clienteRepository.save(cliente);

        return converterParaDTO(cliente);
    }


    public List<ClientePessoaJuridicaDTO> listar() {

        return clienteRepository.findAll()
                .stream()
                .filter(cliente -> cliente instanceof ClientePessoaJuridica)
                .map(cliente -> converterParaDTO((ClientePessoaJuridica) cliente))
                .collect(Collectors.toList());
    }


    public ClientePessoaJuridicaDTO buscarPorId(Long id) {

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Cliente pessoa jurídica não encontrado."));

        if (!(cliente instanceof ClientePessoaJuridica)) {
            throw new ObjetoNaoEncontradoException("Cliente pessoa jurídica não encontrado.");
        }

        ClientePessoaJuridica clientePJ = (ClientePessoaJuridica) cliente;

        return converterParaDTO(clientePJ);
    }


    public ClientePessoaJuridicaDTO atualizar(Long id, ClientePessoaJuridicaDTO dto) {

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Cliente pessoa jurídica não encontrado."));

        if (!(cliente instanceof ClientePessoaJuridica)) {
            throw new ObjetoNaoEncontradoException("Cliente pessoa jurídica não encontrado.");
        }

        ClientePessoaJuridica clientePJ = (ClientePessoaJuridica) cliente;


        SituacaoCliente situacao = situacaoClienteRepository.findById(dto.getSituacaoClienteId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do cliente não encontrada."));


        clientePJ.setTelefone(dto.getTelefone());
        clientePJ.setEmail(dto.getEmail());
        clientePJ.setDataRegistro(dto.getDataRegistro());
        clientePJ.setSituacaoCliente(situacao);

        clientePJ.setRazaoSocial(dto.getRazaoSocial());
        clientePJ.setCnpj(dto.getCnpj());
        clientePJ.setNomeResponsavel(dto.getNomeResponsavel());
        clientePJ.setCpfResponsavel(dto.getCpfResponsavel());

        clienteRepository.save(clientePJ);

        return converterParaDTO(clientePJ);
    }


    public void excluir(Long id) {

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Cliente pessoa jurídica não encontrado."));

        if (!(cliente instanceof ClientePessoaJuridica)) {
            throw new ObjetoNaoEncontradoException("Cliente pessoa jurídica não encontrado.");
        }

        clienteRepository.delete(cliente);
    }


    private ClientePessoaJuridicaDTO converterParaDTO(ClientePessoaJuridica cliente) {

        ClientePessoaJuridicaDTO dto = new ClientePessoaJuridicaDTO();

        dto.setId(cliente.getId());
        dto.setTelefone(cliente.getTelefone());
        dto.setEmail(cliente.getEmail());
        dto.setDataRegistro(cliente.getDataRegistro());
        dto.setSituacaoClienteId(cliente.getSituacaoCliente().getId());

        dto.setRazaoSocial(cliente.getRazaoSocial());
        dto.setCnpj(cliente.getCnpj());
        dto.setNomeResponsavel(cliente.getNomeResponsavel());
        dto.setCpfResponsavel(cliente.getCpfResponsavel());

        return dto;
    }

}