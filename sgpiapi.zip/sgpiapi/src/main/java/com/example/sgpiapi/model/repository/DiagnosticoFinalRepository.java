package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.DiagnosticoFinal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DiagnosticoFinalRepository extends JpaRepository<DiagnosticoFinal, Long> {

}
