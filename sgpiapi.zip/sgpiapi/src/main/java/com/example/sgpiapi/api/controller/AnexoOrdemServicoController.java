package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.AnexoOrdemServicoDTO;
import com.example.sgpiapi.service.AnexoOrdemServicoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/anexo-ordem-servico")
public class AnexoOrdemServicoController {

    private final AnexoOrdemServicoService service;


    public AnexoOrdemServicoController(
            AnexoOrdemServicoService service) {

        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<AnexoOrdemServicoDTO>> listarTodos() {

        return ResponseEntity.ok(service.listarTodos());
    }


    @GetMapping("/{id}")
    public ResponseEntity<AnexoOrdemServicoDTO> buscarPorId(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }


    @PostMapping
    public ResponseEntity<AnexoOrdemServicoDTO> salvar(
            @RequestBody AnexoOrdemServicoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }


    @PutMapping("/{id}")
    public ResponseEntity<AnexoOrdemServicoDTO> atualizar(
            @PathVariable Long id,
            @RequestBody AnexoOrdemServicoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}