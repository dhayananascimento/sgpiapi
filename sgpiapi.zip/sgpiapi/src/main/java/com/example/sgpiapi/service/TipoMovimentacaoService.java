package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.TipoMovimentacaoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.TipoMovimentacao;
import com.example.sgpiapi.model.repository.TipoMovimentacaoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TipoMovimentacaoService {

    @Autowired
    private TipoMovimentacaoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public TipoMovimentacaoDTO salvar(TipoMovimentacaoDTO dto) {

        TipoMovimentacao entity = mapper.map(dto, TipoMovimentacao.class);

        entity = repository.save(entity);

        return mapper.map(entity, TipoMovimentacaoDTO.class);
    }

    public List<TipoMovimentacaoDTO> listar() {

        return repository.findAll()
                .stream()
                .map(entity -> mapper.map(entity, TipoMovimentacaoDTO.class))
                .collect(Collectors.toList());
    }

    public TipoMovimentacaoDTO buscarPorId(Long id) {

        TipoMovimentacao entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Tipo de movimentação não encontrado."));

        return mapper.map(entity, TipoMovimentacaoDTO.class);
    }

    public TipoMovimentacaoDTO atualizar(Long id, TipoMovimentacaoDTO dto) {

        TipoMovimentacao entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Tipo de movimentação não encontrado."));

        entity.setNome(dto.getNome());

        repository.save(entity);

        return mapper.map(entity, TipoMovimentacaoDTO.class);
    }

    public void excluir(Long id) {

        TipoMovimentacao entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Tipo de movimentação não encontrado."));

        repository.delete(entity);
    }

}
