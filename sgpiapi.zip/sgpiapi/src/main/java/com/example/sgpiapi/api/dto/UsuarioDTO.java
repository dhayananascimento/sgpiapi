package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioDTO {

    private Long id;
    private String nomeCompleto;
    private String cpf;
    private String email;
    private String senha;
    private LocalDate dataRegistro;
    private Long situacaoUsuarioId;

}
