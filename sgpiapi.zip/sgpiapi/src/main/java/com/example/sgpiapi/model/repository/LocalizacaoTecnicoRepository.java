package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.LocalizacaoTecnico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LocalizacaoTecnicoRepository extends JpaRepository<LocalizacaoTecnico, Long> {

}
