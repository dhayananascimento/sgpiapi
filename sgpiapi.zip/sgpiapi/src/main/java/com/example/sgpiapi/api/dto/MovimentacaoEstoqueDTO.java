package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MovimentacaoEstoqueDTO {

    private Long id;

    private Long materialId;

    private Long tipoMovimentacaoId;

    private Integer quantidade;

    private LocalDateTime data;

    private String observacao;

}
