package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.TipoRegistroOrdemServicoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.TipoRegistroOrdemServico;
import com.example.sgpiapi.model.repository.TipoRegistroOrdemServicoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TipoRegistroOrdemServicoService {

    @Autowired
    private TipoRegistroOrdemServicoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public TipoRegistroOrdemServicoDTO salvar(TipoRegistroOrdemServicoDTO dto) {

        TipoRegistroOrdemServico tipoRegistro = mapper.map(dto, TipoRegistroOrdemServico.class);

        tipoRegistro = repository.save(tipoRegistro);

        return mapper.map(tipoRegistro, TipoRegistroOrdemServicoDTO.class);
    }

    public List<TipoRegistroOrdemServicoDTO> listar() {

        return repository.findAll()
                .stream()
                .map(tipoRegistro -> mapper.map(tipoRegistro, TipoRegistroOrdemServicoDTO.class))
                .collect(Collectors.toList());
    }

    public TipoRegistroOrdemServicoDTO buscarPorId(Long id) {

        TipoRegistroOrdemServico tipoRegistro = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Tipo de registro da ordem de serviço não encontrado."));

        return mapper.map(tipoRegistro, TipoRegistroOrdemServicoDTO.class);
    }

    public TipoRegistroOrdemServicoDTO atualizar(Long id, TipoRegistroOrdemServicoDTO dto) {

        TipoRegistroOrdemServico tipoRegistro = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Tipo de registro da ordem de serviço não encontrado."));

        tipoRegistro.setNome(dto.getNome());

        repository.save(tipoRegistro);

        return mapper.map(tipoRegistro, TipoRegistroOrdemServicoDTO.class);
    }

    public void excluir(Long id) {

        TipoRegistroOrdemServico tipoRegistro = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Tipo de registro da ordem de serviço não encontrado."));

        repository.delete(tipoRegistro);
    }

}