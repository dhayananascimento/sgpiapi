package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.StatusAtendimentoDTO;
import com.example.sgpiapi.service.StatusAtendimentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/status-atendimentos")
public class StatusAtendimentoController {

    @Autowired
    private StatusAtendimentoService service;

    @PostMapping
    public ResponseEntity<StatusAtendimentoDTO> salvar(@RequestBody StatusAtendimentoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<StatusAtendimentoDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<StatusAtendimentoDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<StatusAtendimentoDTO> atualizar(@PathVariable Long id,
                                                          @RequestBody StatusAtendimentoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}