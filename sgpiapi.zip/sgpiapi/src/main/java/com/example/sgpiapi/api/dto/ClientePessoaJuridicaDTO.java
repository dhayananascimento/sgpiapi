package com.example.sgpiapi.api.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class ClientePessoaJuridicaDTO extends ClienteDTO {

    private String razaoSocial;
    private String cnpj;
    private String nomeResponsavel;
    private String cpfResponsavel;

}
