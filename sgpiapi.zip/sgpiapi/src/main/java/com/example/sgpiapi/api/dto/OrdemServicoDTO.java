package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrdemServicoDTO {

    private Long id;
    private Long contratoId;
    private Long tipoServicoId;
    private Long diagnosticoInicialId;
    private Long prioridadeId;
    private String observacao;
    private LocalDateTime dataAbertura;
    private Long statusOrdemServicoId;
    private Long atendimentoId;

}
