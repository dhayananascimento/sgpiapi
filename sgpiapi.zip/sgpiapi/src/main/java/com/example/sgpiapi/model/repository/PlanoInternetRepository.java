package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.PlanoInternet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PlanoInternetRepository extends JpaRepository<PlanoInternet, Long> {

}
