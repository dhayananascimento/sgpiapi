package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.TecnicoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.Regiao;
import com.example.sgpiapi.model.entity.SituacaoUsuario;
import com.example.sgpiapi.model.entity.Tecnico;
import com.example.sgpiapi.model.entity.Usuario;
import com.example.sgpiapi.model.repository.RegiaoRepository;
import com.example.sgpiapi.model.repository.SituacaoUsuarioRepository;
import com.example.sgpiapi.model.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TecnicoService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private SituacaoUsuarioRepository situacaoUsuarioRepository;

    @Autowired
    private RegiaoRepository regiaoRepository;

    public TecnicoDTO salvar(TecnicoDTO dto) {

        SituacaoUsuario situacao = situacaoUsuarioRepository.findById(dto.getSituacaoUsuarioId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        Regiao regiao = regiaoRepository.findById(dto.getRegiaoPrincipalId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Região não encontrada."));

        Tecnico tecnico = new Tecnico();

        tecnico.setNomeCompleto(dto.getNomeCompleto());
        tecnico.setCpf(dto.getCpf());
        tecnico.setEmail(dto.getEmail());
        tecnico.setSenha(dto.getSenha());
        tecnico.setDataRegistro(dto.getDataRegistro());
        tecnico.setSituacaoUsuario(situacao);
        tecnico.setRegiaoPrincipal(regiao);

        tecnico = (Tecnico) usuarioRepository.save(tecnico);

        return converterParaDTO(tecnico);
    }


    public List<TecnicoDTO> listar() {

        return usuarioRepository.findAll()
                .stream()
                .filter(usuario -> usuario instanceof Tecnico)
                .map(usuario -> converterParaDTO((Tecnico) usuario))
                .collect(Collectors.toList());
    }


    public TecnicoDTO buscarPorId(Long id) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Técnico não encontrado."));

        if (!(usuario instanceof Tecnico)) {
            throw new ObjetoNaoEncontradoException("Técnico não encontrado.");
        }

        Tecnico tecnico = (Tecnico) usuario;

        return converterParaDTO(tecnico);
    }


    public TecnicoDTO atualizar(Long id, TecnicoDTO dto) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Técnico não encontrado."));

        if (!(usuario instanceof Tecnico)) {
            throw new ObjetoNaoEncontradoException("Técnico não encontrado.");
        }

        Tecnico tecnico = (Tecnico) usuario;

        SituacaoUsuario situacao = situacaoUsuarioRepository.findById(dto.getSituacaoUsuarioId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Situação do usuário não encontrada."));

        Regiao regiao = regiaoRepository.findById(dto.getRegiaoPrincipalId())
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Região não encontrada."));

        tecnico.setNomeCompleto(dto.getNomeCompleto());
        tecnico.setCpf(dto.getCpf());
        tecnico.setEmail(dto.getEmail());
        tecnico.setSenha(dto.getSenha());
        tecnico.setDataRegistro(dto.getDataRegistro());
        tecnico.setSituacaoUsuario(situacao);
        tecnico.setRegiaoPrincipal(regiao);

        usuarioRepository.save(tecnico);

        return converterParaDTO(tecnico);
    }


    public void excluir(Long id) {

        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Técnico não encontrado."));

        if (!(usuario instanceof Tecnico)) {
            throw new ObjetoNaoEncontradoException("Técnico não encontrado.");
        }

        usuarioRepository.delete(usuario);
    }


    private TecnicoDTO converterParaDTO(Tecnico tecnico) {

        TecnicoDTO dto = new TecnicoDTO();

        dto.setId(tecnico.getId());
        dto.setNomeCompleto(tecnico.getNomeCompleto());
        dto.setCpf(tecnico.getCpf());
        dto.setEmail(tecnico.getEmail());
        dto.setSenha(tecnico.getSenha());
        dto.setDataRegistro(tecnico.getDataRegistro());
        dto.setSituacaoUsuarioId(tecnico.getSituacaoUsuario().getId());
        dto.setRegiaoPrincipalId(tecnico.getRegiaoPrincipal().getId());

        return dto;
    }

}