package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tipo_atendimento")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TipoAtendimento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    private String descricao;

    @Column(nullable = false)
    private Boolean geraOsAutomatica;

    @ManyToOne
    @JoinColumn(name = "tipo_servico_id")
    private TipoServico tipoServico;
}