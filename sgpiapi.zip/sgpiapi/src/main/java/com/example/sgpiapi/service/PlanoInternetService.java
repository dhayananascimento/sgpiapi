package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.PlanoInternetDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.PlanoInternet;
import com.example.sgpiapi.model.repository.PlanoInternetRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PlanoInternetService {

    @Autowired
    private PlanoInternetRepository repository;

    @Autowired
    private ModelMapper mapper;

    public PlanoInternetDTO salvar(PlanoInternetDTO dto){

        PlanoInternet entity = mapper.map(dto, PlanoInternet.class);

        entity = repository.save(entity);

        return mapper.map(entity, PlanoInternetDTO.class);
    }

    public List<PlanoInternetDTO> listar(){

        return repository.findAll()
                .stream()
                .map(entity -> mapper.map(entity, PlanoInternetDTO.class))
                .collect(Collectors.toList());
    }

    public PlanoInternetDTO buscarPorId(Long id){

        PlanoInternet entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Plano de internet não encontrado."));

        return mapper.map(entity, PlanoInternetDTO.class);
    }

    public PlanoInternetDTO atualizar(Long id, PlanoInternetDTO dto){

        PlanoInternet entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Plano de internet não encontrado."));

        entity.setNome(dto.getNome());
        entity.setVelocidadeMbps(dto.getVelocidadeMbps());
        entity.setValorMensal(dto.getValorMensal());

        repository.save(entity);

        return mapper.map(entity, PlanoInternetDTO.class);
    }

    public void excluir(Long id){

        PlanoInternet entity = repository.findById(id)
                .orElseThrow(() ->
                        new ObjetoNaoEncontradoException("Plano de internet não encontrado."));

        repository.delete(entity);
    }

}
