package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TipoServicoDTO {

    private Long id;
    private String nome;
    private BigDecimal preco;
    private Boolean possuiFidelidade;
    private Integer periodoFidelidadeMeses;

}
