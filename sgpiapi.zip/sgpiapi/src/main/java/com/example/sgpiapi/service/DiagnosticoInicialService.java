package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.DiagnosticoInicialDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.DiagnosticoInicial;
import com.example.sgpiapi.model.repository.DiagnosticoInicialRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DiagnosticoInicialService {

    @Autowired
    private DiagnosticoInicialRepository repository;

    @Autowired
    private ModelMapper mapper;

    public DiagnosticoInicialDTO salvar(DiagnosticoInicialDTO dto) {

        DiagnosticoInicial diagnostico = mapper.map(dto, DiagnosticoInicial.class);

        diagnostico = repository.save(diagnostico);

        return mapper.map(diagnostico, DiagnosticoInicialDTO.class);
    }

    public List<DiagnosticoInicialDTO> listar() {

        return repository.findAll()
                .stream()
                .map(diagnostico -> mapper.map(diagnostico, DiagnosticoInicialDTO.class))
                .collect(Collectors.toList());
    }

    public DiagnosticoInicialDTO buscarPorId(Long id) {

        DiagnosticoInicial diagnostico = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Diagnóstico inicial não encontrado."));

        return mapper.map(diagnostico, DiagnosticoInicialDTO.class);
    }

    public DiagnosticoInicialDTO atualizar(Long id, DiagnosticoInicialDTO dto) {

        DiagnosticoInicial diagnostico = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Diagnóstico inicial não encontrado."));

        diagnostico.setNome(dto.getNome());

        repository.save(diagnostico);

        return mapper.map(diagnostico, DiagnosticoInicialDTO.class);
    }

    public void excluir(Long id) {

        DiagnosticoInicial diagnostico = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Diagnóstico inicial não encontrado."));

        repository.delete(diagnostico);
    }
}