package com.example.sgpiapi.service;

import com.example.sgpiapi.model.entity.Cliente;
import com.example.sgpiapi.model.repository.ClienteRepository;
import com.example.sgpiapi.api.dto.EnderecoDTO;
import com.example.sgpiapi.model.entity.Endereco;
import com.example.sgpiapi.model.entity.Regiao;
import com.example.sgpiapi.model.repository.EnderecoRepository;
import com.example.sgpiapi.model.repository.RegiaoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EnderecoService {

    private final EnderecoRepository repository;
    private final RegiaoRepository regiaoRepository;
    private final ClienteRepository clienteRepository;

public EnderecoService(
        EnderecoRepository repository,
        RegiaoRepository regiaoRepository,
        ClienteRepository clienteRepository) {

    this.repository = repository;
    this.regiaoRepository = regiaoRepository;
    this.clienteRepository = clienteRepository;
}


    public List<EnderecoDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public EnderecoDTO buscarPorId(Long id) {

        Endereco endereco = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Endereço não encontrado"));

        return toDTO(endereco);
    }


    public EnderecoDTO salvar(EnderecoDTO dto) {

        Endereco endereco = new Endereco();

        preencherDados(endereco, dto);

        return toDTO(repository.save(endereco));
    }


    public EnderecoDTO atualizar(Long id, EnderecoDTO dto) {

        Endereco endereco = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Endereço não encontrado"));

        preencherDados(endereco, dto);

        return toDTO(repository.save(endereco));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Endereço não encontrado");
        }

        repository.deleteById(id);
    }


    private void preencherDados(
            Endereco endereco,
            EnderecoDTO dto) {

        endereco.setLogradouro(dto.getLogradouro());
        endereco.setNumero(dto.getNumero());
        endereco.setComplemento(dto.getComplemento());
        endereco.setBairro(dto.getBairro());
        endereco.setCidade(dto.getCidade());
        endereco.setEstado(dto.getEstado());
        endereco.setCep(dto.getCep());
        endereco.setReferencia(dto.getReferencia());

        Regiao regiao = regiaoRepository.findById(dto.getRegiaoId())
                .orElseThrow(() -> new RuntimeException("Região não encontrada"));

	Cliente cliente = clienteRepository.findById(dto.getClienteId())
                .orElseThrow(() ->
                        new RuntimeException("Cliente não encontrado"));

        endereco.setRegiao(regiao);
	endereco.setCliente(cliente);
    }


    private EnderecoDTO toDTO(Endereco endereco) {

        EnderecoDTO dto = new EnderecoDTO();

        dto.setId(endereco.getId());
        dto.setLogradouro(endereco.getLogradouro());
        dto.setNumero(endereco.getNumero());
        dto.setComplemento(endereco.getComplemento());
        dto.setBairro(endereco.getBairro());
        dto.setCidade(endereco.getCidade());
        dto.setEstado(endereco.getEstado());
        dto.setCep(endereco.getCep());
        dto.setReferencia(endereco.getReferencia());

        dto.setRegiaoId(
                endereco.getRegiao().getId()
        );
dto.setClienteId(
        endereco.getCliente().getId()
);

        return dto;
    }
}