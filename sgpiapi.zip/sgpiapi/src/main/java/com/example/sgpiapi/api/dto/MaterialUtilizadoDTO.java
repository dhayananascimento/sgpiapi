package com.example.sgpiapi.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaterialUtilizadoDTO {

    private Long id;
    private Long ordemServicoId;
    private Long materialId;
    private Integer quantidadeUtilizada;
    private LocalDateTime dataHoraRegistro;

}
