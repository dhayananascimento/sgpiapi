package com.example.sgpiapi.model.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalTime;

@Entity
@Table(name = "periodo_atendimento")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PeriodoAtendimento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private LocalTime horaInicial;

    @Column(nullable = false)
    private LocalTime horaFinal;
}