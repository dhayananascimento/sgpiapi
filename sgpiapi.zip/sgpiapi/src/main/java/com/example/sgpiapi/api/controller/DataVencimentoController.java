package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.DataVencimentoDTO;
import com.example.sgpiapi.service.DataVencimentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/datas-vencimento")
public class DataVencimentoController {

    @Autowired
    private DataVencimentoService service;

    @PostMapping
    public ResponseEntity<DataVencimentoDTO> salvar(@RequestBody DataVencimentoDTO dto){
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<DataVencimentoDTO>> listar(){
        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DataVencimentoDTO> buscarPorId(@PathVariable Long id){
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<DataVencimentoDTO> atualizar(@PathVariable Long id,
                                                       @RequestBody DataVencimentoDTO dto){
        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id){
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }

}
