package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.DataVencimentoDTO;
import com.example.sgpiapi.exception.ObjetoNaoEncontradoException;
import com.example.sgpiapi.model.entity.DataVencimento;
import com.example.sgpiapi.model.repository.DataVencimentoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DataVencimentoService {

    @Autowired
    private DataVencimentoRepository repository;

    @Autowired
    private ModelMapper mapper;

    public DataVencimentoDTO salvar(DataVencimentoDTO dto){
        DataVencimento entity = mapper.map(dto, DataVencimento.class);
        entity = repository.save(entity);
        return mapper.map(entity, DataVencimentoDTO.class);
    }

    public List<DataVencimentoDTO> listar(){
        return repository.findAll()
                .stream()
                .map(item -> mapper.map(item, DataVencimentoDTO.class))
                .collect(Collectors.toList());
    }

    public DataVencimentoDTO buscarPorId(Long id){

        DataVencimento entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Data de vencimento não encontrada."));

        return mapper.map(entity, DataVencimentoDTO.class);
    }

    public DataVencimentoDTO atualizar(Long id, DataVencimentoDTO dto){

        DataVencimento entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Data de vencimento não encontrada."));

        entity.setDiaNumerico(dto.getDiaNumerico());
        entity.setDiaExtenso(dto.getDiaExtenso());

        repository.save(entity);

        return mapper.map(entity, DataVencimentoDTO.class);
    }

    public void excluir(Long id){

        DataVencimento entity = repository.findById(id)
                .orElseThrow(() -> new ObjetoNaoEncontradoException("Data de vencimento não encontrada."));

        repository.delete(entity);
    }

}
