package com.example.sgpiapi.service;

import com.example.sgpiapi.api.dto.MaterialUtilizadoDTO;
import com.example.sgpiapi.model.entity.Material;
import com.example.sgpiapi.model.entity.MaterialUtilizado;
import com.example.sgpiapi.model.entity.OrdemServico;
import com.example.sgpiapi.model.repository.MaterialRepository;
import com.example.sgpiapi.model.repository.MaterialUtilizadoRepository;
import com.example.sgpiapi.model.repository.OrdemServicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MaterialUtilizadoService {

    private final MaterialUtilizadoRepository repository;
    private final OrdemServicoRepository ordemServicoRepository;
    private final MaterialRepository materialRepository;


    public MaterialUtilizadoService(
            MaterialUtilizadoRepository repository,
            OrdemServicoRepository ordemServicoRepository,
            MaterialRepository materialRepository) {

        this.repository = repository;
        this.ordemServicoRepository = ordemServicoRepository;
        this.materialRepository = materialRepository;
    }


    public List<MaterialUtilizadoDTO> listarTodos() {

        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }


    public MaterialUtilizadoDTO buscarPorId(Long id) {

        MaterialUtilizado materialUtilizado = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Material utilizado não encontrado"));

        return toDTO(materialUtilizado);
    }


    public MaterialUtilizadoDTO salvar(MaterialUtilizadoDTO dto) {

        MaterialUtilizado materialUtilizado = new MaterialUtilizado();

        preencherDados(materialUtilizado, dto);

        return toDTO(repository.save(materialUtilizado));
    }


    public MaterialUtilizadoDTO atualizar(
            Long id,
            MaterialUtilizadoDTO dto) {


        MaterialUtilizado materialUtilizado = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Material utilizado não encontrado"));


        preencherDados(materialUtilizado, dto);

        return toDTO(repository.save(materialUtilizado));
    }


    public void excluir(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Material utilizado não encontrado");
        }

        repository.deleteById(id);
    }


    private void preencherDados(
            MaterialUtilizado materialUtilizado,
            MaterialUtilizadoDTO dto) {


        OrdemServico ordemServico =
                ordemServicoRepository.findById(dto.getOrdemServicoId())
                        .orElseThrow(() ->
                                new RuntimeException("Ordem de serviço não encontrada"));


        Material material =
                materialRepository.findById(dto.getMaterialId())
                        .orElseThrow(() ->
                                new RuntimeException("Material não encontrado"));


        materialUtilizado.setOrdemServico(ordemServico);
        materialUtilizado.setMaterial(material);
        materialUtilizado.setQuantidade(dto.getQuantidade());
        materialUtilizado.setDataHoraRegistro(dto.getDataHoraRegistro());
    }


    private MaterialUtilizadoDTO toDTO(
            MaterialUtilizado materialUtilizado) {


        MaterialUtilizadoDTO dto = new MaterialUtilizadoDTO();

        dto.setId(materialUtilizado.getId());

        dto.setOrdemServicoId(
                materialUtilizado.getOrdemServico().getId()
        );

        dto.setMaterialId(
                materialUtilizado.getMaterial().getId()
        );

        dto.setQuantidade(
        materialUtilizado.getQuantidade()
);
        dto.setDataHoraRegistro(
                materialUtilizado.getDataHoraRegistro()
        );

        return dto;
    }
}
