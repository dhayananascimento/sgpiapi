package com.example.sgpiapi.api.controller;

import com.example.sgpiapi.api.dto.SituacaoContratoDTO;
import com.example.sgpiapi.service.SituacaoContratoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/situacoes-contratos")
public class SituacaoContratoController {

    @Autowired
    private SituacaoContratoService service;

    @PostMapping
    public ResponseEntity<SituacaoContratoDTO> salvar(@RequestBody SituacaoContratoDTO dto) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.salvar(dto));
    }

    @GetMapping
    public ResponseEntity<List<SituacaoContratoDTO>> listar() {

        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SituacaoContratoDTO> buscarPorId(@PathVariable Long id) {

        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<SituacaoContratoDTO> atualizar(@PathVariable Long id,
                                                         @RequestBody SituacaoContratoDTO dto) {

        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {

        service.excluir(id);

        return ResponseEntity.noContent().build();
    }
}