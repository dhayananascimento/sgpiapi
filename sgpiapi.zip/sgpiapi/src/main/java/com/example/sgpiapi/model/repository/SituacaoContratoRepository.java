package com.example.sgpiapi.model.repository;

import com.example.sgpiapi.model.entity.SituacaoContrato;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SituacaoContratoRepository extends JpaRepository<SituacaoContrato, Long> {

}
