package com.example.sgpiapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SgpiapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SgpiapiApplication.class, args);
	}

}
