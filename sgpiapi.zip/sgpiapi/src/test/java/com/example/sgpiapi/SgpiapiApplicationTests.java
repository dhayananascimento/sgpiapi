package com.example.sgpiapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgpiapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
